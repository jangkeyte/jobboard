<div class="page-top my-2" style="background-image: url({{ asset('uploads/' . ($background_image ?? 'default.png')) }})">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>{{ $heading_text ?? __('Heading') }}</h2>
            </div>
        </div>
    </div>
</div>