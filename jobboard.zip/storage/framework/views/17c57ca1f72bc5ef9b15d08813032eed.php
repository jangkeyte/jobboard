

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Make Payment</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">                
                <h4>Current Plan</h4>
                <div class="row box-items mb-4">
                    <div class="col-md-4 box1">
                        <?php if($current_plan == null): ?>
                        <span class="text-danger">No plan is available</span>
                        <?php else: ?>
                        <h4>$<?php echo e($current_plan->rPackage->package_price); ?></h4>
                        <p><?php echo e($current_plan->rPackage->package_name); ?></p>
                        <?php endif; ?>
                    </div>
                </div>               
                <h4>Choose Plan and Make Payment</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <form action="<?php echo e(route('company_paypal')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <tr>
                                <td>
                                    <select name="package_id" class="form-control select2">
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->package_name); ?> - ($<?php echo e($item->package_price); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td><button href="" class="btn btn-primary">Pay with PayPal</button></td>
                            </tr>
                        </form>
                            <tr>
                                <td>
                                    <select name="package_id" class="form-control select2">
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->package_id); ?>"><?php echo e($item->package_name); ?> - ($<?php echo e($item->package_price); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td><button href="" class="btn btn-primary">Pay with Stripe</button></td>
                            </tr>
                        </form>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/make_payment.blade.php ENDPATH**/ ?>