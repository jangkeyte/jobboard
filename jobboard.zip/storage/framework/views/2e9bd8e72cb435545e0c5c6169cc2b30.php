<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="https://cdn.tiny.cloud/1/fv6j10rupytzz8ao00zifvy2a3ctjp9ef86r1ihxbrduzhin/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/layout/scripts.blade.php ENDPATH**/ ?>