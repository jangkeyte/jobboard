

<?php $__env->startSection('seo_title'); ?><?php echo e($pricing_page_item->title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($pricing_page_item->meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_pricing ?? 'banner_default.jpg'))); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($pricing_page_item->heading ?? __('SEO Heading')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content pricing mt-5">
    <div class="container">
        <div class="row pricing justify-content-center">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card mb-5 border-0 shadow">
                    <div class="card-body px-0">
                        <h2 class="card-title px-3 text-center fw-bold"><?php echo e($item->package_name); ?></h2>
                        <div style="background-color:#F7F7F7;" class="text-center py-3">
                            <h3 class="card-price pt-2 fw-bolder">$<?php echo e($item->package_price); ?></h3>
                            <span class="card-day fs-7"><?php echo e($item->package_days); ?> <?php echo e(__('Days')); ?></span>
                        </div>
                        
                        
                        <ul class="fa-ul px-3 py-3">
                            <li class="py-2">
                                <?php
                                    if ($item->total_allowed_jobs == -1) {
                                        $text = "Unlimited";
                                        $icon_code = "fas fa-check";
                                    } elseif ($item->total_allowed_jobs == 0) {
                                        $text = "{{__('No') }}";
                                        $icon_code = "fas fa-times";
                                    } else {
                                        $text = $item->total_allowed_jobs;
                                        $icon_code = "fas fa-check";
                                    }                                    
                                ?>
                                <span class="fa-li"><i class="<?php echo e($icon_code); ?>"></i></span><?php echo e($text); ?> <?php echo e(__('Job Post Allowed')); ?>

                            </li>
                            <li class="py-2">
                                <?php
                                    if ($item->total_allowed_featured_jobs == -1) {
                                        $text = "Unlimited";
                                        $icon_code = "fas fa-check";
                                    } elseif ($item->total_allowed_featured_jobs == 0) {
                                        $text = "No";
                                        $icon_code = "fas fa-times";
                                    } else {
                                        $text = $item->total_allowed_featured_jobs;
                                        $icon_code = "fas fa-check";
                                    }                                    
                                ?>
                                <span class="fa-li"><i class="<?php echo e($icon_code); ?>"></i></span><?php echo e($text); ?> <?php echo e(__('Featured Job')); ?>

                            </li>
                            <li class="py-2">
                                <?php
                                    if ($item->total_allowed_photos == -1) {
                                        $text = "Unlimited";
                                        $icon_code = "fas fa-check";
                                    } elseif ($item->total_allowed_photos == 0) {
                                        $text = "No";
                                        $icon_code = "fas fa-times";
                                    } else {
                                        $text = $item->total_allowed_photos;
                                        $icon_code = "fas fa-check";
                                    }                                    
                                ?>
                                <span class="fa-li"><i class="<?php echo e($icon_code); ?>"></i></span><?php echo e($text); ?> <?php echo e(__('Company Photos')); ?>

                            </li>
                            <li class="py-2">
                                <?php
                                    if ($item->total_allowed_videos == -1) {
                                        $text = "Unlimited";
                                        $icon_code = "fas fa-check";
                                    } elseif ($item->total_allowed_videos == 0) {
                                        $text = "No";
                                        $icon_code = "fas fa-times";
                                    } else {
                                        $text = $item->total_allowed_videos;
                                        $icon_code = "fas fa-check";
                                    }                                    
                                ?>
                                <span class="fa-li"><i class="<?php echo e($icon_code); ?>"></i></span><?php echo e($text); ?> <?php echo e(__('Company Videos')); ?>

                            </li>
                        </ul>
                        <div class="buy text-center"><a href="" class="btn btn-danger"><?php echo e(__('Choose Plan')); ?></a></div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/pricing.blade.php ENDPATH**/ ?>