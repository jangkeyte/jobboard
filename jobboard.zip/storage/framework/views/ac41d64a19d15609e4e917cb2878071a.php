

<?php $__env->startSection('heading', 'Jobs of company: ' . $companies_detail->company_name ); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_companies')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-folder-check"></i> <?php echo e(__('Back to Previous')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Location</th>
                                    <th>Is Featured?</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $companies_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->rJobCategory->name); ?></td>
                                    <td><?php echo e($item->rJobLocation->name); ?></td>
                                    <td>
                                        <?php if($item->is_featured == 1): ?>
                                        <span class="badge bg-success">Featured</span>
                                        <?php else: ?>
                                        <span class="badge bg-danger">Not Featured</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('job', $item->id)); ?>" title="Job Detail" class="btn btn-primary btn-sm"><i class="bi bi-eye-fill"></i> <?php echo e(__('Detail')); ?></a>
                                        <?php if($item->rCandidateApplication->count() > 0): ?>
                                        <a href="<?php echo e(route('admin_companies_applicants', $item->id)); ?>" title="Applicants" class="btn btn-success btn-sm"><i class="bi bi-people-fill"></i> <?php echo e(__('Applicants')); ?> (<?php echo e($item->rCandidateApplication->count()); ?>)</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/companies_jobs.blade.php ENDPATH**/ ?>