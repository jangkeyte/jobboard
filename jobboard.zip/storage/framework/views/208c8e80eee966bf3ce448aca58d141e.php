

<?php $__env->startSection('heading', 'Send Email to All Subscribers'); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_all_subscribers')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-people"></i> <?php echo e(__('All Subscribers')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin_subscribers_send_email_submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label for="">Subject *</label>
                            <input type="text" class="form-control" name="subject">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Message *</label>
                            <textarea name="message" cols="30" rows="10" class="form-control editor"></textarea>
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btrn btn-primary">Send Email</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/subscribers_send_email.blade.php ENDPATH**/ ?>