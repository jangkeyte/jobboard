

<?php $__env->startSection('seo_title'); ?><?php echo e($post_single->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($post_single->meta_description); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($post_single->heading); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-12">
                <div class="featured-photo">
                    <img src="<?php echo e(asset('uploads/' . $post_single->photo)); ?>" alt="<?php echo e($post_single->title); ?>">                    
                </div>
                <div class="sub">
                    <div class="item">
                        <b><i class="fa fa-clock-o"></i></b>
                        <?php echo $post_single->created_at->format("d"); ?>

                        <?php echo $post_single->created_at->format("F"); ?>

                        <?php echo $post_single->created_at->format("Y"); ?>

                    </div>
                    <div class="item">
                        <b><i class="fa fa-eye"></i></b>
                        <?php echo $post_single->total_view; ?>

                    </div>
                </div>
                <div class="main-text">
                    <?php echo $post_single->description; ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/post.blade.php ENDPATH**/ ?>