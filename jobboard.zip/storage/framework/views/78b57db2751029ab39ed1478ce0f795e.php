<div class="careerfy-table-layer">
    <div class="careerfy-table-row">
        <figure>
            <a href="<?php echo e(route('job', $item->id)); ?>" data-job-id="<?php echo e($item->id); ?>" class="">
                <?php echo $__env->make('front/templates/image', array('image' => $item->rCompany->logo, 'name' => $item->rCompany->company_name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
        </figure>
        <div class="careerfy-featured-listing-text">
            <h2 class="" data-job-id="<?php echo e($item->id); ?>">
                <a href="<?php echo e(route('job', $item->id)); ?>" title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></a>
            </h2>
            <?php if(!Auth::guard('company')->check()): ?>
            <div class="like-btn careerfy-like-list">
                <?php if(Auth::guard('candidate')->check()): ?>
                    <?php
                        $count = \App\Models\CandidateBookmark::where('candidate_id', Auth::guard('candidate')->user()->id)->where('job_id', $item->id)->count();
                        if($count > 0) {
                            $bookmark_status = 'active';
                        } else {
                            $bookmark_status = '';
                        }
                    ?>
                <?php else: ?>
                    <?php $bookmark_status = ''; ?>
                <?php endif; ?>
                <a href="<?php echo e(route('candidate_bookmark_add', $item->id)); ?>"><i class="fas fa-bookmark <?php echo e($bookmark_status); ?>" class="shortlist jobsearch-open-signin-tab careerfy-like-list"></i></a>                    
            </div>
            <?php endif; ?>
            <time datetime="3 December, 2017 12:38 pm"><?php echo e(__('Published')); ?> <?php echo e($item->created_at->diffForHumans()); ?> </time>
            <div class="careerfy-featured-listing-options">
                <ul>
                    <li><i class="careerfy-icon careerfy-maps-and-flags"></i> <?php echo e($item->rJobLocation->name); ?></li>                        
                    <li>
                        <i class="careerfy-icon careerfy-filter-tool-black-shape"></i> 
                        <a href="/jobs-listing?category=<?php echo e($item->rJobCategory->id); ?>" class=""><?php echo e($item->rJobCategory->name); ?></a>
                    </li>
                </ul>
                <a href="" class="careerfy-option-btn" style="background-color: #186fc9 !important; color: #ffffff !important;"> <?php echo e($item->rJobType->name); ?> </a>
            </div>
            <div class="jobsearch-list-excerpt">
                <p>Making it look like readable English. Many desktop publishing packages</p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/job_featured_item.blade.php ENDPATH**/ ?>