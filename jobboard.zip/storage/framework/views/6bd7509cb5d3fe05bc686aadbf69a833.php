

<?php $__env->startSection('heading', 'Applications for job: ' . $job_detail->title ); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_companies')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-folder-check"></i> <?php echo e(__('Back to Previous')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->rCandidate->name); ?></td>
                                    <td><?php echo e($item->rCandidate->email); ?></td>
                                    <td><?php echo e($item->rCandidate->phone); ?></td>
                                    <td>
                                        <?php if($item->status == 'Applied'): ?>
                                            <?php $color="primary"; ?>
                                        <?php elseif($item->status == 'Approved'): ?>
                                            <?php $color="success"; ?>
                                        <?php elseif($item->status == 'Rejected'): ?>
                                            <?php $color="danger"; ?>
                                        <?php else: ?>
                                            <?php $color="warning"; ?>
                                        <?php endif; ?>
                                        <span class="badge bg-<?php echo e($color); ?>"><?php echo e($item->status); ?></span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin_companies_applicant_resume', $item->candidate_id)); ?>" title="Candidate Detail" class="btn btn-primary btn-sm"><i class="bi bi-eye-fill"></i> <?php echo e(__('Detail')); ?></a>
                                        <a href="" data-bs-toggle="modal" data-bs-target="#coverLetterModal<?php echo e($item->id); ?>" title="Cover Letter" class="btn btn-warning btn-sm"><i class="bi bi-envelope-fill"></i> <?php echo e(__('CV')); ?></a>
                                    </td>
                                </tr>
                                <!-- Modal -->
                                <div class="modal fade" id="coverLetterModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="coverLetterModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="coverLetterModalLabel">Cover Letter</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <?php echo nl2br($item->cover_letter); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/companies_applicants.blade.php ENDPATH**/ ?>