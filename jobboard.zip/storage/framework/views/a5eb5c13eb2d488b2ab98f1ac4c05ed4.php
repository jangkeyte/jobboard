<div class="top">
    <div class="container">
        <div class="row pt-2">
            <div class="col-md-6 left-side">
                <ul class="header-left ps-0">
                    <li class="email-text"><a href="mailto:<?php echo e($global_settings_data->top_bar_email); ?>"><i class="fa-solid fa-envelope text-danger"></i> <span><?php echo e($global_settings_data->top_bar_email); ?></span></a></li>
                    <li class="phone-text ms-3"><a href="tel:<?php echo e($global_settings_data->top_bar_phone); ?>"><i class="fa-solid fa-phone text-danger"></i> <span><?php echo e($global_settings_data->top_bar_phone); ?></span></a></li>
                </ul>
            </div>
            <div class="col-md-6 right-side text-end">
                <ul class="header-right social mr-auto">
                    <li><a href="<?php echo e($global_settings_data->facebook); ?>"><i class="fa-brands fa-facebook fa-lg hover-color-danger"></i></a></li>
                    <li><a href="<?php echo e($global_settings_data->twitter); ?>"><i class="fa-brands fa-twitter fa-lg hover-color-danger"></i></a></li>
                    <li><a href="<?php echo e($global_settings_data->pinterest); ?>"><i class="fa-brands fa-google-plus fa-lg hover-color-danger"></i></a></li>
                    <li><a href="<?php echo e($global_settings_data->linkedin); ?>"><i class="fa-brands fa-linkedin fa-lg hover-color-danger"></i></a></li>
                    <?php if(app()->getLocale() == 'vi'): ?>
                    <li class="menu"><a href="<?php echo route('switch_language', ['en']); ?>"><img src="<?php echo e(asset('uploads/flags/united-kingdom.svg')); ?>" alt="English" title="<?php echo e(__('English')); ?>" class="mx-1" style="width:24px;"></a></li>
                    <?php else: ?>
                    <li class="menu"><a href="<?php echo route('switch_language', ['vi']); ?>"><img src="<?php echo e(asset('uploads/flags/vietnam.svg')); ?>" alt="Tiếng Việt" title="<?php echo e(__('Tiếng Việt')); ?>" class="mx-1" style="width:24px"></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('front.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/layout/header.blade.php ENDPATH**/ ?>