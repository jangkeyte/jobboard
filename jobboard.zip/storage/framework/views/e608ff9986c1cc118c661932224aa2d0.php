
<li class="nav-item  <?php echo e(Request::is('admin/dashboard') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link">
        <i class="nav-icon bi bi-speedometer"></i>
        <p>
            <?php echo e(__('Dashboard')); ?>

            <i class="nav-arrow bi bi-chevron-right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="<?php echo e(route('admin_dashboard')); ?>" class="nav-link">
                <i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/dashboard') ? '-fill' : ''); ?>"></i>
                <p><?php echo e(__('Dashboard')); ?></p>
            </a>
        </li>
    </ul>
</li>

<li class="nav-item <?php echo e(Request::is('admin/home-page') || Request::is('admin/faq-page') || Request::is('admin/blog-page') || Request::is('admin/term-page') || Request::is('admin/privacy-page') || Request::is('admin/contact-page') || Request::is('admin/job-category-page') || Request::is('admin/pricing-page') || Request::is('admin/other-page') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(Request::is('admin/home-page') || Request::is('admin/faq-page') || Request::is('admin/blog-page') || Request::is('admin/term-page') || Request::is('admin/privacy-page') || Request::is('admin/contact-page') || Request::is('admin/category-page') || Request::is('admin/pricing-page') || Request::is('admin/other-page') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-sliders"></i>
        <p>
            <?php echo e(__('Page Settings')); ?>

            <i class="nav-arrow bi bi-chevron-right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/home-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_home_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/home-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Home')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/faq-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_faq_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/faq-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('FAQ')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/blog-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_blog_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/blog-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Blog')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/term-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_term_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/term-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Terms of Use')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/privacy-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_privacy_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/privacy-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Privacy Policy')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/contact-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_contact_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/contact-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Contact')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/category-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_category_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-category-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Category')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/pricing-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_pricing_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/pricing-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Pricing')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/other-page') ? 'active' : ''); ?>" href="<?php echo e(route('admin_other_page')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/other-page') ? '-fill' : ''); ?>"></i> <?php echo e(__('Other')); ?></a></li>
    </ul>
</li>

<li class="nav-item <?php echo e(Request::is('admin/job-category/*') || Request::is('admin/job-location/*') || Request::is('admin/job-type/*') || Request::is('admin/job-experience/*') || Request::is('admin/job-gender/*') || Request::is('admin/job-salary-range/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(Request::is('admin/job-category/*') || Request::is('admin/job-location/*') || Request::is('admin/job-type/*') || Request::is('admin/job-experience/*') || Request::is('admin/job-gender/*') || Request::is('admin/job-salary-range/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-person-workspace"></i>
        <p>
            <?php echo e(__('Job Section')); ?>

            <i class="nav-arrow bi bi-chevron-right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/job-category/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_category')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-category/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Category')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/job-location/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_location')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-location/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Location')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/job-type/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_type')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-type/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Type')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/job-experience/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_experience')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-experience/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Experience')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/job-gender/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_gender')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-gender/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Gender')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/job-salary-range/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_job_salary_range')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/job-salary-range/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Job Salary Range')); ?></a></li>
    </ul>
</li>

<li class="nav-item <?php echo e(Request::is('admin/company-location/*') || Request::is('admin/company-industry/*') || Request::is('admin/company-size/*') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(Request::is('admin/company-location/*') || Request::is('admin/company-industry/*') || Request::is('admin/company-size/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-buildings"></i>
        <p>
            <?php echo e(__('Company Section')); ?>

            <i class="nav-arrow bi bi-chevron-right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/company-location/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_company_location')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/company-location/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Company Location')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/company-industry/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_company_industry')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/company-industry/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Company Industry')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/company-size/*') ? 'active' : ''); ?>" href="<?php echo e(route('admin_company_size')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/company-size/*') ? '-fill' : ''); ?>"></i> <?php echo e(__('Company Size')); ?></a></li>
    </ul>
</li>

<!-- SUBSCRIBERS -->
<li class="nav-item <?php echo e(Request::is('admin/all-subscribers') || Request::is('admin/subscribers-send-email') ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(Request::is('admin/all-subscribers') || Request::is('admin/subscribers-send-email') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-postcard-fill"></i>
        <p>
            <?php echo e(__('Subscriber Section')); ?>

            <i class="nav-arrow bi bi-chevron-right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/all-subscribers') ? 'active' : ''); ?>" href="<?php echo e(route('admin_all_subscribers')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/all-subscribers') ? '-fill' : ''); ?>"></i> <?php echo e(__('All Subscribers')); ?></a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(Request::is('admin/subscribers-send-email') ? 'active' : ''); ?>" href="<?php echo e(route('admin_subscribers_send_email')); ?>"><i class="nav-icon bi bi-caret-right<?php echo e(Request::is('admin/subscribers-send-email') ? '-fill' : ''); ?>"></i> <?php echo e(__('Send mail to Subscribers')); ?></a></li>
    </ul>
</li>

<!-- COMPANY -->
<li class="nav-item">
    <a href="<?php echo e(route('admin_companies')); ?>" class="nav-link <?php echo e(Request::is('admin/companies') || Request::is('admin/companies-detail/*') || Request::is('admin/companies-jobs/*') || Request::is('admin/companies-applicants/*') || Request::is('admin/companies-applicant-resume/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-person-fill-check"></i> <p><?php echo e(__('Company Profile')); ?></p>
    </a>
</li>

<!-- CANDIDATE -->
<li class="nav-item">
    <a href="<?php echo e(route('admin_candidates')); ?>" class="nav-link <?php echo e(Request::is('admin/candidates') || Request::is('admin/candidates-detail/*') || Request::is('admin/candidates-apllied-jobs/*') || Request::is('admin/candidates-delete/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-person-fill-check"></i> <p><?php echo e(__('Candidate Profile')); ?></p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('admin_why_choose_item')); ?>" class="nav-link <?php echo e(Request::is('admin/why-choose/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-person-fill-check"></i> <p><?php echo e(__('Why Choose Items')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_testimonial')); ?>" class="nav-link <?php echo e(Request::is('admin/testimonial/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-person-video2"></i> <p><?php echo e(__('Testimonials')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_post')); ?>" class="nav-link <?php echo e(Request::is('admin/post/*') ? 'active' : ''); ?>"">
        <i class="nav-icon bi bi-file-earmark-post-fill"></i> <p><?php echo e(__('Posts')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_faq')); ?>" class="nav-link <?php echo e(Request::is('admin/faq/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-question-circle-fill"></i> <p><?php echo e(__('Faqs')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_package')); ?>" class="nav-link <?php echo e(Request::is('admin/package/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-ui-checks-grid"></i> <p><?php echo e(__('Packages')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_advertisement')); ?>" class="nav-link <?php echo e(Request::is('admin/advertisement') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-badge-ad"></i> <p><?php echo e(__('Advertisement')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_banner')); ?>" class="nav-link <?php echo e(Request::is('admin/banner') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-card-image"></i> <p><?php echo e(__('Banners')); ?></p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo e(route('admin_settings')); ?>" class="nav-link <?php echo e(Request::is('admin/settings/*') ? 'active' : ''); ?>">
        <i class="nav-icon bi bi-gear"></i> <p><?php echo e(__('Settings')); ?></p>
    </a>
</li>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/layout/menu.blade.php ENDPATH**/ ?>