

<?php $__env->startSection('heading', 'Edit Testimonial Items'); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_testimonial')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-folder-check"></i> <?php echo e(__('View All')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin_testimonial_update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($testimonial_single->id); ?>">
                        <div class="form-group mb-3">
                            <label>Existing Photo</label>
                            <div><img src="<?php echo e(asset('uploads/' . $testimonial_single->photo)); ?>" alt="" class="" style="width:150px"></div>
                        </div>
                        <div class="form-group mb-3">
                            <label>Change Photo *</label>
                            <input type="file" class="form-control" name="photo">
                        </div>
                        <div class="form-group mb-3">
                            <label>Name *</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($testimonial_single->name); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Designation *</label>
                            <input type="text" class="form-control" name="designation" value="<?php echo e($testimonial_single->designation); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Comment *</label>
                            <textarea name="comment" class="form-control" cols="30" rows="10"><?php echo e($testimonial_single->comment); ?></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/testimonial_edit.blade.php ENDPATH**/ ?>