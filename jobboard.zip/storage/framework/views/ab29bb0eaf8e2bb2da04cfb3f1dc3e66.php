

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Apply for job: <?php echo e($job_single->title); ?></h2>
                <div class="button"><a href="<?php echo e(route('job', $job_single->id)); ?>" class="btn btn-primary btn-sm">See Job Detail</a></div>
            </div>
        </div>
    </div>
</div>

<div class="job-apply">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center">
                <div class="apply-form">
                    <form action="<?php echo e(route('candidate_apply_submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($job_single->id); ?>">
                        <div class="mb-3">
                            <label for="" class="mb-1">Cover Letter *</label>
                            <textarea name="cover_letter" cols="30" rows="10" class="form-control editor"></textarea>
                            <div class="clearfix"></div>
                        </div>
                        <div class="mb-3">
                            <button tyle="submit" class="btn btn-primary btn-sm">Confirm Apply</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/candidate/apply.blade.php ENDPATH**/ ?>