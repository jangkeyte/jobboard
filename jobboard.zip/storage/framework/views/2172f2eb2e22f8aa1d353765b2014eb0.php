<!DOCTYPE html>
<html lang="vi">    
<!--begin::Head-->
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <title>AdminLTE v4 | <?php echo $__env->yieldContent('heading'); ?></title>
   <link rel="icon" type="image/png" href="<?php echo e(asset('uploads/' . $global_settings_data->favicon)); ?>" />
   
   <!--begin::Primary Meta Tags-->
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="title" content="AdminLTE v4 | Dashboard">
   <meta name="author" content="Jang Keyte - Kha Thiết Giang">
   <meta name="description" content="">
   <meta name="keywords" content=""><!--end::Primary Meta Tags-->         
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <?php echo $__env->make('admin.layout.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

</head> <!--end::Head--> 
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper"> 
        <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
        <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--begin::App Main-->
        <main class="app-main"> 
            <!--begin::App Content Header-->
            <div class="app-content-header"> 
                <!--begin::Container-->
                <div class="container-fluid">                     
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0"><?php echo $__env->yieldContent('heading'); ?> <?php echo $__env->yieldContent('button'); ?></h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin_home')); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?php echo $__env->yieldContent('heading'); ?></li>
                            </ol>
                        </div>
                    </div> <!--end::Row-->
                </div> <!--end::Container-->
            </div> <!--end::App Content Header-->           

            <!--begin::App Content-->
            <div class="app-content"> 
                <!--begin::Container-->
                <div class="container-fluid"> 
                    <!--begin::Main Content-->
                    <?php echo $__env->yieldContent('main_content'); ?> <!--end::Main Content-->
                </div> <!--end::Container-->
            </div> <!--end::App Content-->

        </main> <!--end::App Main-->

        <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div> <!--end::App Wrapper--> 
</body><!--end::Body-->
</html><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>