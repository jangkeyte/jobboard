<div class="footer mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="item">
                    <h5 class="heading"><?php echo e(__('For Candidates')); ?></h5>
                    <ul class="useful-links">
                        <li><a href="<?php echo e(route('job_listing')); ?>"><?php echo e(__('Browser Jobs')); ?></a></li>
                        <li><a href="<?php echo e(route('candidate_bookmark_view')); ?>"><?php echo e(__('Bookmarked Jobs')); ?></a></li>
                        <li><a href="<?php echo e(route('candidate_dashboard')); ?>"><?php echo e(__('Candidate Dashboard')); ?></a></li>
                        <li><a href="<?php echo e(route('candidate_apply_view')); ?>"><?php echo e(__('Apllied Jobs')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="item">
                    <h5 class="heading"><?php echo e(__('For Companies')); ?></h5>
                    <ul class="useful-links">
                        <li><a href="<?php echo e(route('company_jobs_create')); ?>"><?php echo e(__('Post New Job')); ?></a></li>
                        <li><a href="<?php echo e(route('company_listing')); ?>"><?php echo e(__('Browse Company')); ?></a></li>
                        <li><a href="<?php echo e(route('company_dashboard')); ?>"><?php echo e(__('Company Dashboard')); ?></a></li>
                        <li><a href="<?php echo e(route('company_candidate_applications')); ?>"><?php echo e(__('Applications')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="item">
                    <h5 class="heading"><?php echo e(__('For Companies')); ?></h5>
                    <ul class="useful-links">
                        <li><a href="<?php echo e(route('terms')); ?>"><?php echo e(__('Terms of Use')); ?></a></li>
                        <li><a href="<?php echo e(route('privacy')); ?>"><?php echo e(__('Privacy Policy')); ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="item">
                    <h5 class="heading"><?php echo e(__('Contact')); ?></h5>
                    <div class="list-item">
                        <div class="left">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="right">
                            <?php echo e($global_settings_data->footer_address); ?>

                        </div>
                    </div>
                    <div class="list-item">
                        <div class="left">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="right">
                            <?php echo e($global_settings_data->footer_phone); ?>

                        </div>
                    </div>
                    <div class="list-item">
                        <div class="left">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="right">
                            <?php echo e($global_settings_data->footer_email); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 text-center mt-5">
                <ul class="header-right social mr-auto">
                    <li><a href="<?php echo e($global_settings_data->facebook); ?>"><i class="px-2 fs-1 fa-brands fa-facebook-f fa-lg hover-color-danger"></i></a></li>
                    <li><a href="<?php echo e($global_settings_data->twitter); ?>"><i class="px-2 fs-1 fa-brands fa-twitter fa-lg hover-color-danger"></i></a></li>
                    <li><a href="<?php echo e($global_settings_data->pinterest); ?>"><i class="px-2 fs-1 fa-brands fa-google-plus fa-lg hover-color-danger"></i></a></li>
                    <li><a href="<?php echo e($global_settings_data->linkedin); ?>"><i class="px-2 fs-1 fa-brands fa-linkedin fa-lg hover-color-danger"></i></a></li>                    
                </ul>
            </div>

            <div class="col-md-12 text-center mt-2">
                <ul class="header-right social mr-auto">
                    <?php if(app()->getLocale() == 'vi'): ?>
                    <li class="menu"><a href="<?php echo route('switch_language', ['en']); ?>"><img src="<?php echo e(asset('uploads/flags/united-kingdom.svg')); ?>" alt="English" title="<?php echo e(__('English')); ?>" class="mx-2" style="width:24px;"> English</a></li>
                    <?php else: ?>
                    <li class="menu"><a href="<?php echo route('switch_language', ['vi']); ?>"><img src="<?php echo e(asset('uploads/flags/vietnam.svg')); ?>" alt="Tiếng Việt" title="<?php echo e(__('Tiếng Việt')); ?>" class="mx-2" style="width:24px"> Tiếng Việt</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="copyright">
                    <?php echo e(__('Copyright 2024, JangKeyte. All Rights Reserved.')); ?>

                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="right">
                    
                </div>
            </div>
        </div>
    </div>
</div>

<div class="scroll-top">
    <i class="fas fa-angle-up"></i>
</div>

<?php echo $__env->make('front.layout.scripts_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if( $errors->any() ): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <script>
            iziToast.error({
                title: '',
                position: 'topCenter',
                message: '<?php echo e($error); ?>',
            });
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if( session()->get('error') ): ?>
    <script>        
        iziToast.error({
            title: '',
            position: 'topRight',
            message: '<?php echo e(session()->get("error")); ?>',
        });
    </script>
<?php endif; ?>

<?php if( session()->get('success') ): ?>
    <script>        
        iziToast.success({
            title: '',
            position: 'topRight',
            message: '<?php echo e(session()->get("success")); ?>',
        });
    </script>
<?php endif; ?>

<script>
    $(".form_subscribe_ajax").on('submit', function(e){
        e.preventDefault();
        //$('#loader').show();
        var form = this;
        $.ajax({
            url:$(form).attr('action'),
            method:$(form).attr('method'),
            data:new FormData(form),
            processData:false,
            dataType:'json',
            contentType:false,
            beforeSend:function(){
                $(form).find('span.error-text').text('');
            },
            success:function(data){
                //$('#loader').hide();
                if(data.code == 0) {
                    $.each(data.error_message, function(prefix, val){
                        $(form).find('span.' + prefix + '_error').text(val[0]);
                    });
                } else if(data.code == 1) {
                    $(form)[0].reset();
                    iziToast.success({
                        title: '',
                        position: 'topRight',
                        message: data.success_message,
                    })
                }
            }
        });
    })

    Splide.defaults = {
        type   : 'loop',
        perPage: 2,
    }
</script>
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/layout/footer.blade.php ENDPATH**/ ?>