

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Job Title</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-top page-top-company-single" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 company company-single">
                <div class="item d-flex justify-content-start">
                    <div class="logo"><img src="<?php echo e(asset('uploads/' . $company_single->logo)); ?>"></div>
                    <div class="text">
                        <h3><?php echo e($company_single->title); ?>, <?php echo e($company_single->company_name); ?></h3>
                        <div class="detail-1 d-flex justify-content-start">
                            <div class="category"><?php echo e($company_single->rCompanyIndustry->name); ?></div>
                            <div class="location"><?php echo e($company_single->rCompanyLocation->name); ?></div>
                            <div class="email"><?php echo e($company_single->email); ?></div>
                            <?php if($company_single->phone != ''): ?>
                            <div class="phone"><?php echo e($company_single->phone); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="special">
                            <div class="type"><?php echo e($company_single->r_job_count); ?> Open Postions</div>
                            <?php if($company_single->facebook != '' || $company_single->twitter != '' || $company_single->linkedin != '' || $company_single->instagram != ''): ?>
                            <div class="social">
                                <ul>
                                    <?php if($company_single->facebook != ''): ?>
                                        <li><a href="<?php echo e($company_single->facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                    <?php endif; ?>
                                    <?php if($company_single->twitter != ''): ?>
                                        <li><a href="<?php echo e($company_single->twitter); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                    <?php endif; ?>
                                    <?php if($company_single->linkedin != ''): ?>
                                        <li><a href="<?php echo e($company_single->linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                    <?php endif; ?>
                                    <?php if($company_single->instagram != ''): ?>
                                        <li><a href="<?php echo e($company_single->instagram); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="apply">
                            <a href="" class="btn btn-primary save-company">Bookmark</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="company-result pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Description</h2>
                    <p><?php echo $company_single->description; ?></p>
                </div>
                <?php if($company_single->oh_mon != null || $company_single->oh_tue || $company_single->oh_web || $company_single->oh_thu || $company_single->oh_fri || $company_single->oh_sat || $company_single->oh_sun): ?>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Opening Hours</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <td>Monday</td>
                                <td><?php echo e($company_single->oh_mon ?? 'Off-day'); ?></td>
                            </tr>
                            <tr>
                                <td>Tuesday</td>
                                <td><?php echo e($company_single->oh_tue ?? 'Off-day'); ?></td>
                            </tr>
                            <tr>
                                <td>Webnesday</td>
                                <td><?php echo e($company_single->oh_web ?? 'Off-day'); ?></td>
                            </tr>
                            <tr>
                                <td>Thursday</td>
                                <td><?php echo e($company_single->oh_thu ?? 'Off-day'); ?></td>
                            </tr>
                            <tr>
                                <td>Friday</td>
                                <td><?php echo e($company_single->oh_fri ?? 'Off-day'); ?></td>
                            </tr>
                            <tr>
                                <td>Saturday</td>
                                <td><?php echo e($company_single->oh_sat ?? 'Off-day'); ?></td>
                            </tr>
                            <tr>
                                <td>Sunday</td>
                                <td><?php echo e($company_single->oh_sun ?? 'Off-day'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if($company_photos->count() != 0): ?>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Photos</h2>
                    <div class="photo-all">
                        <div class="row">
                            <?php $__currentLoopData = $company_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="item">
                                    <a href="<?php echo e(asset('uploads/' . $item->photo)); ?>" class="magnific">
                                        <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" alt="">
                                        <div class="icon"><i class="fas fa-plus"></i></div>
                                        <div class="bg"></div>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($company_videos->count() != 0): ?>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Videos</h2>
                    <div class="video-all">
                        <div class="row">
                            <?php $__currentLoopData = $company_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="item">
                                    <a href="https://www.youtobe.com/watch/?v=<?php echo e($item->video); ?>" class="video-button">
                                        <img src="https://img.youtube.com/vi/<?php echo e($item->video); ?>/0.jpg" alt="">
                                        <div class="icon"><i class="far fa-play-circle"></i></div>
                                        <div class="bg"></div>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Open Positions</h2>
                    <div class="job related-job pt-0 pb-0">
                        <div class="container">
                            <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-md-12">
                                        <div class="item d-flex justify-content-start">
                                            <div class="logo">
                                                <img src="<?php echo e(asset('uploads/' . $item->rCompany->logo)); ?>" alt="<?php echo e($company_single->company_name); ?>">
                                            </div>
                                            <div class="text">
                                                <h3>
                                                    <a href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?>, <?php echo e($company_single->company_name); ?></a>
                                                </h3>
                                                <div class="detail-1 d-flex justify-content-start">
                                                    <div class="category"><?php echo e($item->rJobCategory->name); ?></div>
                                                    <div class="location"><?php echo e($item->rJobLocation->name); ?></div>
                                                </div>
                                                <div class="detail-2 d-flex-justify-content-start">
                                                    <div class="date"><?php echo e($item->created_at->diffForHumans()); ?></div>
                                                    <div class="budget"><?php echo e($item->rJobSalaryRange->name); ?></div>
                                                    <?php if(date('Y-m-d') > $item->deadline): ?>
                                                    <div class="expired">Expired</div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="special d-flex justify-content-start">
                                                    <?php if($item->is_featured == 1): ?><div class="featured">Featured</div> <?php endif; ?>
                                                    <div class="type"><?php echo e($item->rJobType->name); ?></div>
                                                    <?php if($item->is_urgent == 1): ?><div class="urgent">Urgent</div> <?php endif; ?>
                                                </div>
                                                <div class="bookmark">
                                                    <a href=""><i class="fas fa-bookmark active"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                
                                    <div class="text-danger">No related job found.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-12">
                <div class="right-item">
                    <h2><i class="fas fa-file-invoice"></i> Company Overview</h2>
                    <div class="summary">
                        <div class="table-responsive">
                            <table class="rable table-bordered">
                                <tr>
                                    <td><b>Contact Person:</b></td>
                                    <td><?php echo e($company_single->person_name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Industry:</b></td>
                                    <td><?php echo e($company_single->rCompanyIndustry->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Location:</b></td>
                                    <td><?php echo e($company_single->rCompanyLocation->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Company Size:</b></td>
                                    <td><?php echo e($company_single->rCompanySize->name); ?></td>
                                </tr>
                                <?php if($company_single->address != null): ?>
                                <tr>
                                    <td><b>Address:</b></td>
                                    <td><?php echo e($company_single->address); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td><b>Email:</b></td>
                                    <td><?php echo e($company_single->email); ?></td>
                                </tr>
                                <?php if($company_single->address != null): ?>
                                <tr>
                                    <td><b>Phone:</b></td>
                                    <td><?php echo e($company_single->phone); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td><b>Founded On:</b></td>
                                    <td><?php echo e($company_single->founded_on); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Website:</b></td>
                                    <td><a href="<?php echo e($company_single->website); ?>" target="_blank"><?php echo e($company_single->website); ?></a></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="right-item">
                    <h2><i class="fas fa-file-invoice"></i> Contact Company</h2>
                    <div class="enquery-form">
                        <form action="<?php echo e(route('company_enquery_email')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="company_email" value="<?php echo e($company_single->email); ?>">
                            <div class="mb-3">
                                <input type="text" class="form-control" name="visitor_name" placeholder="Full Name">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" name="visitor_email" placeholder="Email Address">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" name="visitor_phone" placeholder="Phone Number">
                            </div>
                            <div class="mb-3">
                                <textarea name="visitor_message" cols="30" rows="10" placeholder="Message"></textarea>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <?php if($company_single->map_code != null): ?>
                <div class="right-item">
                    <h2><i class="fas fa-file-invoice"></i> Location Map</h2>
                    <div class="location-map">
                        <?php echo nl2br($company_single->map_code); ?>

                    </div>
                </div>
                <?php endif; ?>
            
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/company.blade.php ENDPATH**/ ?>