

<?php $__env->startSection('heading', 'Companies Detail'); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_companies')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-folder-check"></i> <?php echo e(__('Back to Previous')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5>Basic Infomation</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <tr>
                                <th style="width:200px">Logo</th>
                                <td><img src="<?php echo e(asset('uploads/' . $companies_detail?->logo)); ?>" alt="" class="w-100"></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Company Name</th>
                                <td><?php echo e($companies_detail?->company_name); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Person Name</th>
                                <td><?php echo e($companies_detail?->person_name); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Username</th>
                                <td><?php echo e($companies_detail?->username); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Email</th>
                                <td><?php echo e($companies_detail?->email); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Phone</th>
                                <td><?php echo e($companies_detail?->phone); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Address</th>
                                <td><?php echo e($companies_detail?->address); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Industry</th>
                                <td><?php echo e($companies_detail?->rCompanyIndustry?->name); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Location</th>
                                <td><?php echo e($companies_detail?->rCompanyLocation?->name); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Sizez</th>
                                <td><?php echo e($companies_detail?->rCompanySize?->name); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Found On</th>
                                <td><?php echo e($companies_detail?->founded_on); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Website</th>
                                <td><?php echo e($companies_detail?->website); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Description</th>
                                <td><?php echo $companies_detail?->description; ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Opening Hours</th>
                                <td>
                                    Monday: <?php echo e($companies_detail?->oh_mon); ?><br>
                                    Tuesday: <?php echo e($companies_detail?->oh_tue); ?><br>
                                    Wednesday: <?php echo e($companies_detail?->oh_web); ?><br>
                                    Thursday: <?php echo e($companies_detail?->oh_thu); ?><br>
                                    Friday: <?php echo e($companies_detail?->oh_fri); ?><br>
                                    Saturday: <?php echo e($companies_detail?->oh_sat); ?><br>
                                    Sunday: <?php echo e($companies_detail?->oh_sun); ?><br>
                                </td>
                            </tr>
                            <tr>
                                <th style="width:200px">Facebook</th>
                                <td><?php echo e($companies_detail?->facebook); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Twitter</th>
                                <td><?php echo e($companies_detail?->twitter); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Instagram</th>
                                <td><?php echo e($companies_detail?->instagram); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Linkedin</th>
                                <td><?php echo e($companies_detail?->linkedin); ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Google Map</th>
                                <td><?php echo $companies_detail?->map_code; ?></td>
                            </tr>
                            <tr>
                                <th style="width:200px">Photos</th>
                                <td>                                
                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" alt="" style="width:200px">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <tr>
                                <th style="width:200px">Videos</th>
                                <td>                 
                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="https://img.youtube.com/vi/<?php echo e($item->video); ?>/0.jpg" alt="" style="width:200px">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/companies_detail.blade.php ENDPATH**/ ?>