

<?php $__env->startSection('heading', 'Candidate Detail'); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_candidates')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-folder-check"></i> <?php echo e(__('Back to Previous')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">   
                <h4 class="resume">Basic Profile</h4>
                <div class="table-respnsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>Photo</th>
                            <td><img src="<?php echo e(asset('uploads/' . $candidate_single->photo)); ?>" style="width:120px"></td>
                        </tr>

                        <?php if($candidate_single->name != null): ?>
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($candidate_single->name); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->designation != null): ?>
                        <tr>
                            <th>Designation</th>
                            <td><?php echo e($candidate_single->designation); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->email != null): ?>
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($candidate_single->email); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->phone != null): ?>
                        <tr>
                            <th>Phone</th>
                            <td><?php echo e($candidate_single->phone); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->country != null): ?>
                        <tr>
                            <th>Country</th>
                            <td><?php echo e($candidate_single->country); ?></td>
                        </tr>
                        <?php endif; ?>
                        
                        <?php if($candidate_single->address != null): ?>
                        <tr>
                            <th>Address</th>
                            <td><?php echo e($candidate_single->address); ?></td>
                        </tr>
                        <?php endif; ?>
                        
                        <?php if($candidate_single->state != null): ?>
                        <tr>
                            <th>State</th>
                            <td><?php echo e($candidate_single->state); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->city != null): ?>
                        <tr>
                            <th>City</th>
                            <td><?php echo e($candidate_single->city); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->zip_code != null): ?>
                        <tr>
                            <th>Zip Code</th>
                            <td><?php echo e($candidate_single->zip_code); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->gender != null): ?>
                        <tr>
                            <th>Gender</th>
                            <td><?php echo e($candidate_single->gender); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->marital_status != null): ?>
                        <tr>
                            <th>Marital Status</th>
                            <td><?php echo e($candidate_single->marital_status); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->date_of_birth != null): ?>
                        <tr>
                            <th>Date of Birth</th>
                            <td><?php echo e($candidate_single->date_of_birth); ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->website != null): ?>
                        <tr>
                            <th>Website</th>
                            <td><a href="<?php echo e($candidate_single->website); ?>"><?php echo e($candidate_single->website); ?></a></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($candidate_single->biography != null): ?>
                        <tr>
                            <th>Biography</th>
                            <td><?php echo $candidate_single->biography; ?></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>

                <?php if($candidate_educations->count()): ?>
                <h4 class="resume">Education</h4>
                <div class="table-respnsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>SL</th>
                            <th>Education Level</th>
                            <th>Institute</th>
                            <th>Degree</th>
                            <th>Passing Year</th>
                        </tr>
                        <?php $__currentLoopData = $candidate_educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->level); ?></td>
                            <td><?php echo e($item->institute); ?></td>
                            <td><?php echo e($item->degree); ?></td>
                            <td><?php echo e($item->passing_year); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php endif; ?>
                
                <?php if($candidate_skills->count()): ?>
                <h4 class="resume">Skill</h4>
                <div class="table-respnsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>SL</th>
                            <th>Skill Name</th>
                            <th>Percentage</th>
                        </tr>
                        <?php $__currentLoopData = $candidate_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->percentage); ?>%</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php endif; ?>

                <?php if($candidate_work_experiences->count()): ?>
                <h4 class="resume">Experience</h4>
                <div class="table-respnsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>SL</th>
                            <th>Company</th>
                            <th>Designation</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                        </tr>
                        <?php $__currentLoopData = $candidate_work_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->company); ?></td>
                            <td><?php echo e($item->designation); ?></td>
                            <td><?php echo e($item->start_date); ?></td>
                            <td><?php echo e($item->end_date); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php endif; ?>

                <?php if($candidate_awards->count()): ?>
                <h4 class="resume">Awards</h4>
                <div class="table-respnsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>SL</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Date</th>
                        </tr>
                        <?php $__currentLoopData = $candidate_awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <td><?php echo e($item->date); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php endif; ?>

                <?php if($candidate_resumes->count()): ?>
                <h4 class="resume">Resume</h4>
                <div class="table-respnsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>File</th>
                        </tr>
                        <?php $__currentLoopData = $candidate_resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><a href="<?php echo e(asset('uploads/' . $item->file)); ?>" target="_blank"><?php echo e($item->file); ?></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/candidates_detail.blade.php ENDPATH**/ ?>