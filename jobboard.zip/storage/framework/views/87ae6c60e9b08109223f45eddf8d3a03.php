

<?php $__env->startSection('seo_title'); ?><?php echo e($other_page_item->candidate_listing_page_title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($other_page_item->candidate_listing_page_meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_candidate_listing ?? 'banner_default.jpg'))); ?>)">
    <div class="container">
        <div class="row pt-3">
            <div class="col-md-12 text-white text-center py-5">
                <h2 class="fw-bold"><?php echo e($other_page_item->candidate_listing_page_heading ?? __('Candidate Listing')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="path">
    <div class="container">
        <div class="row pt-2">
            <div class="col-md-12 text-white text-center">
                <ul class="d-inline fs-7">
                    <li><a class="text-white" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                    <li class="px-2"> > </li>
                    <li><?php echo e(__('Candidate Listing')); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<div class="candidate-result mt-3">
    <div class="container">
        <div class="row pt-2">
            <div class="col-md-3">
                <?php echo $__env->make('front/templates/candidate_listing_search_form', array('form_data' => $form_data, 'candidate_sectors' => $candidate_sectors, 'advertisement_data' => $advertisement_data), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-md-9">
                <div class="job">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="search-result-header">
                                    <div class="row">
                                        <div class="col-md-6 left-side">
                                            <ul class="header-left ps-0">
                                                <li class="email-text">
                                                    <div><span class="fs-5 fw-bolder text-black"><?php echo e($candidates->count()); ?> <?php echo e(__('Companies Found')); ?></span></div>
                                                    <div class="mt-1"><span class="fs-7 fw-bolder"><?php echo e(__('Displayed Here')); ?>: 1-14 <?php echo e(__('Companies')); ?></span></div>
                                                </li>
                                            </ul>                                            
                                        </div>
                                        <div class="col-md-6 right-side text-end">
                                            <ul class="header-right social mr-auto ">
                                                <li><a href="<?php echo e($global_settings_data->facebook); ?>"><i class="fa fa-sort"></i></a></li>
                                                <span class=" text-danger ps-1" ><?php echo e(__('Most Recent')); ?></span>
                                                <li><a href="<?php echo e($global_settings_data->facebook); ?>"><i class="fa fa-sort t"></i></a></li>
                                                <span class=" text-danger ps-1" ><?php echo e(__('Records Per Page')); ?></span>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if(!$candidates->count()): ?>
                                <div class="text-danger"><?php echo e(__('No result found')); ?></div>
                            <?php else: ?>
                                <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 border careerfy-refejobs-list careerfy-refejobs-list-two p-0 mb-2">
                                        <div class="container p-0">
                                            <?php echo $__env->make('front/templates/candidate_listing_candidate_item', array('item' => $item), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-12">
                                    
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    $(".form_subscribe_ajax").on('submit', function(e){
        e.preventDefault();
        //$('#loader').show();
        var form = this;
        $.ajax({
            url:$(form).attr('action'),
            method:$(form).attr('method'),
            data:new FormData(form),
            processData:false,
            dataType:'json',
            contentType:false,
            beforeSend:function(){
                $(form).find('span.error-text').text('');
            },
            success:function(data){
                //$('#loader').hide();
                if(data.code == 0) {
                    $.each(data.error_message, function(prefix, val){
                        $(form).find('span.' + prefix + '_error').text(val[0]);
                    });
                } else if(data.code == 1) {
                    $(form)[0].reset();
                    iziToast.success({
                        title: '',
                        position: 'topRight',
                        message: data.success_message,
                    })
                }
            }
        });
    })
</script>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/candidate_listing.blade.php ENDPATH**/ ?>