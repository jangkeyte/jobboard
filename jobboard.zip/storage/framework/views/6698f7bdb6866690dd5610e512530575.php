

<?php $__env->startSection('seo_title'); ?><?php echo e($contact_page_item->title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($contact_page_item->meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_contact ?? 'banner_default.jpg'))); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($contact_page_item->heading ?? __('SEO Heading')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content">
    <div class="container">
        <div class="row mt-3">
            <div class="col-md-4 col-sm-12 p-3">
                <div class="contact-form border p-4 bg-danger text-white">
                    <h2 class="pb-3 fw-bolder"><?php echo e(__('Contact Information')); ?></h2>
                    <hr/>
                    <p>
                        N?i dung gi?i thi?u v? c�ng ty
                    </p>
                    <ul class="list-unstyled">
                        <li class="py-3">
                            <i class="fa fa-location-dot px-1"></i>
                            <?php echo e(__('�?a ch?')); ?>: Nguy?n tr�i
                        </li>
                        <li class="py-3">
                            <i class="fa fa-envelope px-1"></i>
                            <a class="text-white" href="mailto:info@website.com"><?php echo e(__('Email')); ?>: info@website.com</a>
                        </li>
                        <li class="py-3">
                            <i class="fa fa-phone px-1"></i>
                            <?php echo e(__('Call')); ?>: 123.456.78910
                        </li>
                        <li class="py-3">
                            <i class="fa fa-fax px-1"></i>
                            <?php echo e(__('Fax')); ?>: (800) 123 4567 89
                        </li>
                    </ul>
                    <div class="careerfy-contact-media">
                        <a href="#">
                            <i class="careerfy-icon careerfy-facebook-logo"></i>
                        </a>
                        <a href="#">
                            <i class="careerfy-icon careerfy-twitter-logo"></i>
                        </a>
                        <a href="#">
                            <i class="careerfy-icon careerfy-linkedin-button"></i>
                        </a>
                        <a href="#">
                            <i class="careerfy-icon careerfy-dribbble-logo"></i>
                        </a>
                    </div>
                </div>
            </div>


            <div class="col-lg-8 col-sm-12 p-3">
                <div class="contact-form border p-4">
                    <form action="<?php echo e(route('contact_submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="" class="form-label"><?php echo e(__('Name')); ?></label>
                            <input type="text" class="form-control" name="person_name">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label"><?php echo e(__('Email Address')); ?></label>
                            <input type="text" class="form-control" name="person_email">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label"><?php echo e(__('Message')); ?></label>
                            <textarea name="person_message" id="" cols="30" rows="10" class="form-control"></textarea>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-danger hover-outline bg-website"><?php echo e(__('Send Message')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- <div class="col-lg-6 col-md-12">
                <div class="map">
                    <?php echo $contact_page_item->map_code ?? ''; ?>

                </div>
            </div> -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/contact.blade.php ENDPATH**/ ?>