

<?php $__env->startSection('seo_title'); ?><?php echo e($blog_page_item->title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($blog_page_item->meta_description); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($blog_page_item->heading); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="blog">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="item">
                    <div class="photo">
                        <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" alt="<?php echo e($item->title); ?>">
                    </div>
                    <div class="text">
                        <h2>
                            <a href="<?php echo e(route('post', $item->slug)); ?>">
                                <?php echo e($item->title); ?>

                            </a>
                        </h2>
                        <div class="short-des">
                            <p><?php echo e(nl2br($item->short_description)); ?></p>
                        </div>
                        <div class="button">
                            <a href="<?php echo e(route('post', $item->slug)); ?>" class="btn btn-primary">
                                Read More
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12">
                <?php echo e($posts->links()); ?>

            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/blog.blade.php ENDPATH**/ ?>