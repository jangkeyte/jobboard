

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . $global_banner_data->banner_company_panel)); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e(__('All Jobs')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <tbody>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(__('Title')); ?></th>
                                <th><?php echo e(__('Category')); ?></th>
                                <th><?php echo e(__('Location')); ?></th>
                                <th><?php echo e(__('Is Featured')); ?>?</th>
                                <th><?php echo e(__('Action')); ?></th>
                            </tr>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->rJobCategory->name); ?></td>
                                <td><?php echo e($item->rJobLocation->name); ?></td>
                                <td>
                                    <?php if($item->is_featured == 1): ?>
                                    <span class="badge bg-success"><?php echo e(__('Featured')); ?></span>
                                    <?php else: ?>
                                    <span class="badge bg-danger"><?php echo e(__('Not Featured')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('company_jobs_edit', $item->id)); ?>" class="btn btn-warning btn-sm text-white"><i class="fas fa-edit"></i></a>
                                    <a href="<?php echo e(route('company_jobs_delete', $item->id)); ?>" class="btn btn-danger btn-sm" onClick="return confirm('<?php echo e(__('Are you sure')); ?>?');"><i class="fas fa-trash-alt"></i></aa>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/jobs.blade.php ENDPATH**/ ?>