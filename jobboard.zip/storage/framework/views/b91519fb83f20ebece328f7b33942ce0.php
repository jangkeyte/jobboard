

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Jobs Listing</h2>
            </div>
        </div>
    </div>
</div>
<div class="job-result">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="job-filter">
                    <form action="<?php echo e(url('job-listing')); ?>" method="get">
                        <div class="widget">
                            <h2>Job Title</h2>
                            <input type="text" class="form-control" name="title" value="<?php echo e($form_title); ?>">
                        </div>
                        <div class="widget">
                            <h2>Job Category</h2>
                            <select name="category" class="form-control select2">
                                <option value="">Job Category</option>
                                <?php $__currentLoopData = $job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_category == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Job Location</h2>
                            <select name="location" class="form-control select2">
                                <option value="">Job Location</option>
                                <?php $__currentLoopData = $job_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_location == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Job Type</h2>
                            <select name="type" class="form-control select2">
                                <option value="">Job Type</option>
                                <?php $__currentLoopData = $job_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_type == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Experience</h2>
                            <select name="experience" class="form-control select2">
                                <option value="">Experience</option>
                                <?php $__currentLoopData = $job_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_experience == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Gender</h2>
                            <select name="gender" class="form-control select2">
                                <option value="">Gender</option>
                                <?php $__currentLoopData = $job_genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_gender == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Salary Range</h2>
                            <select name="salary_range" class="form-control select2">
                                <option value="">Salary Range</option>
                                <?php $__currentLoopData = $job_salary_ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_salary_range == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="filter-button">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="fas fa-search"></i> <?php echo e($home_page_data->search ?? 'Filter'); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-9">
                <div class="job">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="search-result-header">
                                    <i class="fas fa-search"></i> Search Result for Job Listing
                                </div>
                            </div>
                            <?php if(!$jobs->count()): ?>
                                <div class="text-danger">No result found</div>
                            <?php else: ?>
                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <div class="item d-flex justify-content-start">
                                            <div class="logo">
                                                <img src="<?php echo e(asset('uploads/' . $item->rCompany->logo)); ?>" alt="<?php echo e($item->rCompany->company_name); ?>">
                                            </div>
                                            <div class="text">
                                                <h3>
                                                    <a href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?>, <?php echo e($item->rCompany->company_name); ?></a>
                                                </h3>
                                                <div class="detail-1 d-flex justify-content-start">
                                                    <div class="category"><?php echo e($item->rJobCategory->name); ?></div>
                                                    <div class="location"><?php echo e($item->rJobLocation->name); ?></div>
                                                </div>
                                                <div class="detail-2 d-flex-justify-content-start">
                                                    <div class="date"><?php echo e($item->created_at->diffForHumans()); ?></div>
                                                    <div class="budget"><?php echo e($item->rJobSalaryRange->name); ?></div>
                                                    <?php if(date('Y-m-d') > $item->deadline): ?>
                                                    <div class="expired">Expired</div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="special d-flex justify-content-start">
                                                    <?php if($item->is_featured == 1): ?><div class="featured">Featured</div> <?php endif; ?>
                                                    <div class="type"><?php echo e($item->rJobType->name); ?></div>
                                                    <?php if($item->is_urgent == 1): ?><div class="urgent">Urgent</div> <?php endif; ?>
                                                </div>
                                                <div class="bookmark">
                                                    <a href=""><i class="fas fa-bookmark active"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <?php echo e($jobs->links()); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/job_listing.blade.php ENDPATH**/ ?>