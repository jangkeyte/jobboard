<div class="careerfy-refejobs-list-inner">
    <?php if($item->is_urgent): ?>
    <span class="urgntpkg-jobv1"><?php echo e(__('urgent')); ?></span>
    <?php endif; ?>
    <figure>
        <a href="<?php echo e(route('job', $item->id)); ?>">
            <?php echo $__env->make('front/templates/image', array('image' => $item->rCompany->logo, 'name' => $item->rCompany->company_name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </a>
        <figcaption>
            <h2>
                <a href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?></a>
            </h2>
            <span><a href="<?php echo e(route('company', $item->company_id)); ?>"><?php echo e($item->rCompany->company_name); ?></a></span>
        </figcaption>
    </figure>
    <small><i class="fa-solid fa-briefcase text-danger"></i><?php echo e($item->rJobCategory->name); ?></small> 
    <small><i class="fa-solid fa-location-dot text-danger"></i><?php echo e($item->rJobLocation->name); ?></small>
    <small><i class="fa-solid fa-money-bill text-danger"></i> <?php echo e($item->rJobSalaryRange->name); ?> / <?php echo e(__('Monthly')); ?></small>
    <small><i class="fa-solid fa-calendar text-danger"></i><?php echo e($item->deadline); ?></small>
    <a href="<?php echo e(route('job', $item->id)); ?>" class="careerfy-refejobs-list-btn"><span><?php echo e(__('Apply')); ?></span></a>
</div>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/job_refered_item.blade.php ENDPATH**/ ?>