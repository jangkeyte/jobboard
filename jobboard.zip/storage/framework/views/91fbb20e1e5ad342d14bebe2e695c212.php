

<?php $__env->startSection('heading', 'Edit Posts'); ?>

<?php $__env->startSection('button'); ?>
<a href="<?php echo e(route('admin_post')); ?>" class="btn btn-primary btn-sm ms-2"><i class="bi bi-folder-check"></i> <?php echo e(__('View All')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin_post_update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($post_single->id); ?>">
                        <div class="form-group mb-3">
                            <label>Heading *</label>
                            <input type="text" class="form-control" name="heading" value="<?php echo e($post_single->heading); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Slug *</label>
                            <input type="text" class="form-control" name="slug" value="<?php echo e($post_single->slug); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Short Description *</label>
                            <textarea name="short_description" class="form-control" cols="30" rows="5"><?php echo e($post_single->short_description); ?></textarea>
                        </div>
                        <div class="form-group mb-3">
                            <label>Description *</label>
                            <textarea name="description" class="form-control editor" cols="30" rows="15"><?php echo e($post_single->description); ?></textarea>
                        </div>
                        <div class="form-group mb-3">
                            <label>Existing Photo</label>
                            <div><img src="<?php echo e(asset('uploads/' . $post_single->photo)); ?>" alt="" class="" style="width:150px"></div>
                        </div>
                        <div class="form-group mb-3">
                            <label>Change Photo *</label>
                            <input type="file" class="form-control" name="photo">
                        </div>
                        <h4 class="seo_section">SEO Section</h5>
                        <div class="form-group mb-3">
                            <label>Title</label>
                            <input type="text" class="form-control" name="title" value="<?php echo e($post_single->title); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Meta Description *</label>
                            <textarea name="meta_description" class="form-control" cols="30" rows="15"><?php echo e($post_single->meta_description); ?></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/post_edit.blade.php ENDPATH**/ ?>