<div class="top">
    <div class="container">
        <div class="row">
            <div class="col-md-6 left-side">
                <ul>
                    <li class="phone-text">111-222-3333</li>
                    <li class="email-text">contact@jangkeyte.com</li>
                </ul>
            </div>
            <div class="col-md-6 right-side">
                <ul class="right">
                    <?php if(Auth::guard('company')->check()): ?>
                    <li class="menu"><a href="<?php echo e(route('company_dashboard')); ?>"><i class="fa-solid fa-house"></i> Dashboard</a></li>
                    <?php elseif(Auth::guard('candidate')->check()): ?>
                    <li class="menu"><a href="<?php echo e(route('candidate_dashboard')); ?>"><i class="fa-solid fa-house"></i> Dashboard</a></li>
                    <?php else: ?>
                    <li class="menu"><a href="<?php echo e(route('login')); ?>"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                    <li class="menu"><a href="<?php echo e(route('signup')); ?>"><i class="fas fa-user"></i> Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('front.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/layout/header.blade.php ENDPATH**/ ?>