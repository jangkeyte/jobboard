

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Edit Education</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('candidate.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <a href="<?php echo e(route('candidate_education')); ?>" class="bt btn-primary btn-sm mb-2"><i class="fas fa-plus"></i> See All</a>
                <form action="<?php echo e(route('candidate_education_update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($education_single->id); ?>">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="" class="form-label">Education Level *</label>
                            <input type="text" class="form-control" name="level" value="<?php echo e($education_single->level); ?>">
                        </div>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="" class="form-label">Institute *</label>
                        <input type="text" class="form-control" name="institute" value="<?php echo e($education_single->institute); ?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="" class="form-label">Degree *</label>
                        <input type="text" class="form-control" name="degree" value="<?php echo e($education_single->degree); ?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="" class="form-label">Passing Year *</label>
                        <input type="text" class="form-control" name="passing_year" value="<?php echo e($education_single->passing_year); ?>">
                    </div>
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </div>
                </form>                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/candidate/education_edit.blade.php ENDPATH**/ ?>