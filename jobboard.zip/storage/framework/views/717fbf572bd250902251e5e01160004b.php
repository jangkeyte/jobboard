

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Dashboard</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <h3>Hello, <?php echo e(Auth::guard('company')->user()->person_name); ?> (<?php echo e(Auth::guard('company')->user()->company_name); ?>)</h3>
                <p>See all the statistics at a glance:</p>

                <div class="row box-items">
                    <div class="col-md-4">
                        <div class="box1">
                            <h4><?php echo e($total_opened_jobs); ?></h4>
                            <p>Open Jobs</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box2">
                            <h4><?php echo e($total_featured_jobs); ?></h4>
                            <p>Featured Jobs</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box3">
                            <h4><?php echo e($total_urgent_jobs); ?></h4>
                            <p>Pending Jobs Jobs</p>
                        </div>
                    </div>
                </div>
                
                <h3 class="mt-5">Recent Jobs</h3>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>SL</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Location</th>
                                <th>Is Featured?</th>
                                <th>Is Urgent?</th>
                            </tr>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->rJobCategory->name); ?></td>
                                <td><?php echo e($item->rJobLocation->name); ?></td>
                                <td>
                                    <?php if($item->is_featured == 1): ?>
                                    <span class="badge bg-success">Featured</span>
                                    <?php else: ?>
                                    <span class="badge bg-danger">Not Featured</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($item->is_urgent == 1): ?>
                                    <span class="badge bg-danger">Urgent</span>
                                    <?php else: ?>
                                    <span class="badge bg-primary">Not Urgent</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/dashboard.blade.php ENDPATH**/ ?>