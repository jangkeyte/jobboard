

<?php $__env->startSection('seo_title'); ?><?php echo e($other_page_item->company_listing_page_title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($other_page_item->company_listing_page_meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_company_listing ?? 'banner_default.jpg'))); ?>)">
    <div class="container">
        <div class="row pt-3">
            <div class="col-md-12 text-white text-center py-5">
                <h2 class="fw-bold"><?php echo e($other_page_item->company_listing_page_heading ?? __('SEO Heading')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="path">
    <div class="container">
        <div class="row pt-2">
            <div class="col-md-12 text-white text-center">
                <ul class="d-inline fs-7">
                    <li><a class="text-white" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                    <li class="px-2"> > </li>
                    <li><?php echo e(__('Companies Listing')); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<div class="company-result mt-3">
    <div class="container">
        <div class="row pt-2">
            <div class="col-md-3">
                <?php echo $__env->make('front/templates/company_listing_search_form', array('form_data' => $form_data, 'company_industries' => $company_industries, 'company_locations' => $company_locations, 'company_sizes' => $company_sizes, 'advertisement_data' => $advertisement_data), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-md-9">
                <div class="job">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="search-result-header">
                                    <div class="row">
                                        <div class="col-md-6 left-side">
                                            <ul class="header-left ps-0">
                                                <li class="email-text">
                                                    <div><span class="fs-5 fw-bolder text-black"><?php echo e($companies->count()); ?> <?php echo e(__('Companies Found')); ?></span></div>
                                                    <div class="mt-1"><span class="fs-7 fw-bolder"><?php echo e(__('Displayed Here')); ?>: 1-14 <?php echo e(__('Companies')); ?></span></div>
                                                </li>
                                            </ul>                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if(!$companies->count()): ?>
                                <div class="text-danger"><?php echo e(__('No result found')); ?></div>
                            <?php else: ?>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 my-2 border">                                        
                                        <div class="row">
                                            <div class="col-md-12 text-end pe-0">
                                                <span class="promotepof-badgeemp"><i class="fa fa-star pe-1" title="Featured"></i><?php echo e(__('Featured')); ?></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-1 pb-3 pt-2 ">
                                                    <a href="<?php echo e(route('company', $item->id)); ?>" style="width:85px; height:85px; display: block;">
                                                        <?php echo $__env->make('front/templates/image', array('image' => $item->logo, 'name' => $item->company_name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </a>
                                            </div>
                                            <div class="col-md-8 pt-2 ps-5">
                                                <ul class="list-unstyled fs-7">
                                                    <li><a class ="text-danger" href="javascript:void(0);"><?php echo e($item->rCompanyIndustry->name); ?></a></li>
                                                    <li class="pt-1"><h7><a class="fw-bold" href="<?php echo e(route('company', $item->id)); ?>"><?php echo e($item->company_name); ?></a></h7></li>
                                                    <li class="pt-1"><i class="pe-1 fa fa-location-dot"></i><?php echo e($item->rCompanyLocation->name); ?></li>
                                                </ul>
                                            </div>

                                            <div class="col-md-3 pt-3 mt-2">
                                                <ul class="list-unstyled fs-7">
                                                    <li>
                                                        <button type="submit" class="btn btn-outline hover-danger rounded-1 btn-follow me-2"><i class="fa fa-user-plus pe-2"></i><?php echo e(__('Follow')); ?></button>
                                                        <button type="submit" class="btn btn-outline hover-danger rounded-1 btn-follow"><?php echo e($item->r_job_sum_vacancy); ?> <?php echo e(__('Vacancy')); ?></button>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    $(".form_subscribe_ajax").on('submit', function(e){
        e.preventDefault();
        //$('#loader').show();
        var form = this;
        $.ajax({
            url:$(form).attr('action'),
            method:$(form).attr('method'),
            data:new FormData(form),
            processData:false,
            dataType:'json',
            contentType:false,
            beforeSend:function(){
                $(form).find('span.error-text').text('');
            },
            success:function(data){
                //$('#loader').hide();
                if(data.code == 0) {
                    $.each(data.error_message, function(prefix, val){
                        $(form).find('span.' + prefix + '_error').text(val[0]);
                    });
                } else if(data.code == 1) {
                    $(form)[0].reset();
                    iziToast.success({
                        title: '',
                        position: 'topRight',
                        message: data.success_message,
                    })
                }
            }
        });
    })
</script>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/company_listing.blade.php ENDPATH**/ ?>