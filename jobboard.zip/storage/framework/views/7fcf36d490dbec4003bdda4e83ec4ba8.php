<div class="col-md-12 py-2">
    <div class="row border">
        <div class="col-md-1 pt-4">
            <a href="<?php echo e(route('job', $item->id)); ?>" style="width:58px; height:58px; display: block;">
                <?php echo $__env->make('front/templates/image', array('image' => $item->rCompany->logo, 'name' => $item->rCompany->company_name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
        </div>
        <div class="col-md-9 pt-3">
            <div>
                <h5><a class="fw-bold" href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?></a></h5>
                <ul class="list-unstyled fs-7">
                    <li>
                            <a class ="text-danger" href="<?php echo e(route('company', $item->company_id)); ?>"><?php echo e($item->rCompany->company_name); ?></a>
                            <i class="ms-1 px-1 border-start fa fa-location-dot"></i><?php echo e($item->rJobLocation->name); ?>

                            <?php if($item->is_featured == 1): ?><div class="featured badge text-bg-primary"><?php echo e(__('Featured')); ?></div> <?php endif; ?>
                            <?php if($item->is_urgent == 1): ?><div class="urgent badge text-bg-danger"><?php echo e(__('Urgent')); ?></div> <?php endif; ?>
                    </li>
                    <li>
                        <i class="px-1 fa fa-calendar-days"></i><?php echo e(__('Published')); ?> <?php echo e($item->created_at->diffForHumans()); ?>

                        <?php if(date('Y-m-d') > $item->deadline): ?>
                            <div class="expired badge text-bg-warning"><?php echo e(__('Expired')); ?></div>
                        <?php endif; ?>
                    </li>
                    <li>
                        <i class="px-1 fa fa-filter"></i><?php echo e($item->rJobCategory->name); ?>

                        <i class="ms-1 px-1 border-start fa fa-dollar-sign"></i><?php echo e($item->rJobSalaryRange->name); ?>

                    </li>
                </ul>
            </div>
        </div>

        <div class="col-md-2 pt-5">
            <ul class="list-unstyled fs-7">
                <li>
                    <?php if($item->rJobType->id == 1): ?><button type="submit" class="btn btn-fulltime rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                    <?php if($item->rJobType->id == 2): ?><button type="submit" class="btn btn-parttime rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                    <?php if($item->rJobType->id == 3): ?><button type="submit" class="btn btn-freelance rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                    <?php if($item->rJobType->id == 4): ?><button type="submit" class="btn btn-temporary rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                    <?php if($item->rJobType->id == 5): ?><button type="submit" class="btn btn-internship rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                    
                    <?php if(!Auth::guard('company')->check()): ?>
                        <?php if(Auth::guard('candidate')->check()): ?>
                            <?php
                                $count = \App\Models\CandidateBookmark::where('candidate_id', Auth::guard('candidate')->user()->id)->where('job_id', $item->id)->count();
                                if($count > 0) {
                                    $bookmark_status = 'bg-danger';
                                } else {
                                    $bookmark_status = '';
                                }
                            ?>
                        <?php else: ?>
                            <?php $bookmark_status = ''; ?>
                        <?php endif; ?>
                        <a class="icon-job-like fa-solid fa-heart bg-danger" href="<?php echo e(route('candidate_bookmark_add', $item->id)); ?>"><i class="fa fa-heart"></i></a>
                    <?php endif; ?>
                    
                </li>
            </ul>

        </div>
    </div>
</div>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/job_listing_job_item.blade.php ENDPATH**/ ?>