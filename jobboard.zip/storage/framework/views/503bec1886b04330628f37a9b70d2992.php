<div class="container">
    <form action="<?php echo e(route('job_listing')); ?>" mothod="get">
        <div class="inner">
            <div class="row">
                <div class="col-lg-6 col-md-8 mt-2">
                    <div class="form-group">
                        <input type="text" name="title" class="form-control" placeholder="<?php echo e(__('Job Title')); ?>">
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
                    <div class="form-group">
                        <select name="location" class="form-select select2">
                            <option value=""><?php echo e(__('Job Location')); ?></option>
                            <?php $__currentLoopData = $all_job_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
                    <div class="form-group">
                        <select name="category" class="form-select select2">
                            <option value=""><?php echo e(__('Job Category')); ?></option>
                            <?php $__currentLoopData = $all_job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
                    <div class="form-group">
                        <select name="type" class="form-select select2">
                            <option value=""><?php echo e(__('Job Type')); ?></option>
                            <?php $__currentLoopData = $all_job_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
                    <div class="form-group">
                        <select name="experience" class="form-select select2">
                            <option value=""><?php echo e(__('Job Experience')); ?></option>
                            <?php $__currentLoopData = $all_job_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
                    <div class="form-group">
                        <select name="salary_range" class="form-select select2">
                            <option value=""><?php echo e(__('Job Salary Range')); ?></option>
                            <?php $__currentLoopData = $all_job_salary_ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 d-grid gap-2 mt-2">
                    <button type="submit" class="btn text-white" style="width: 100%;margin: 0;height: 42px;background: orange;border: none;"><i class="fas fa-search"></i> <?php echo e(__('Search')); ?></button>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/home_search_form.blade.php ENDPATH**/ ?>