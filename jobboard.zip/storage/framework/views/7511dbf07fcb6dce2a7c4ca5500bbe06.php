

<?php $__env->startSection('seo_title'); ?><?php echo e($home_page_data->title ?? 'Title'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($home_page_data->meta_description ?? 'Meta Description'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<?php if(isset($home_page_data)): ?>

<div class="slider" style="background-image: url(<?php echo e(asset('uploads/' . ($home_page_data->background ?? 'background_default.jpg'))); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="item">
                    <div class="text">
                        <h2><?php echo e($home_page_data->heading ?? 'Heading'); ?></h2>
                        <p>
                            <?php echo e($home_page_data->text ?? 'Text'); ?>

                        </p>
                    </div>
                    <div class="search-section">
                        <form action="<?php echo e(route('job_listing')); ?>" mothod="get">
                            <div class="inner">
                                <div class="row">
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <input type="text" name="title" class="form-control" placeholder="<?php echo e($home_page_data->job_title); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <select name="location" class="form-select select2">
                                                <option value=""><?php echo e($home_page_data->job_location); ?></option>
                                                <?php $__currentLoopData = $all_job_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <select name="category" class="form-select select2">
                                                <option value=""><?php echo e($home_page_data->job_category); ?></option>
                                                <?php $__currentLoopData = $all_job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <input type="hidden" name="type">
                                        <input type="hidden" name="experience">
                                        <input type="hidden" name="gender">
                                        <input type="hidden" name="salary_range">
                                        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> <?php echo e($home_page_data->search); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($home_page_data->job_category_status == 'Show'): ?>
<div class="job-category">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading">
                    <h2><?php echo e($home_page_data->job_category_heading); ?></h2>
                    <p><?php echo e($home_page_data->job_category_subheading); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="item">
                    <div class="icon">
                        <i class="<?php echo e($item->icon); ?>"></i>
                    </div>
                    <h3><a href="<?php echo e(url('job-listing?category=' . $item->id)); ?>"><?php echo e($item->name); ?></a></h3>
                    <p>(<?php echo e($item->r_job_count); ?> Open Positions)</p>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(route('job_categories')); ?>" class="btn btn-primary">See All Categories</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($home_page_data->why_choose_status == 'Show'): ?>
<div class="why-choose" style="background-image: url(<?php echo e(asset('uploads/' . ($home_page_data->why_choose_background ?? 'background_default.jpg'))); ?>)">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading">
                    <h2><?php echo e($home_page_data->why_choose_heading); ?></h2>
                    <p><?php echo e($home_page_data->why_choose_subheading); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $why_choose_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="inner">
                    <div class="icon">
                        <i class="<?php echo e($item->icon); ?>"></i>
                    </div>
                    <div class="text">
                        <h2><?php echo e($item->heading); ?></h2>
                        <p><?php echo e(nl2br($item->text)); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($home_page_data->featured_jobs_status == 'Show'): ?>
<div class="job">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading">
                    <h2><?php echo e($home_page_data->featured_jobs_heading); ?></h2>
                    <p><?php echo e($home_page_data->featured_jobs_subheading); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $featured_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 col-md-12">
                <div class="item d-flex justify-content-start">
                    <div class="logo">
                        <img src="<?php echo e(asset('uploads/' . $item->rCompany->logo)); ?>" alt="<?php echo e($item->rCompany->company_name); ?>">
                    </div>
                    <div class="text">
                        <h3>
                            <a href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?>, <?php echo e($item->rCompany->company_name); ?></a>
                        </h3>
                        <div class="detail-1 d-flex justify-content-start">
                            <div class="category"><?php echo e($item->rJobCategory->name); ?></div>
                            <div class="location"><?php echo e($item->rJobLocation->name); ?></div>
                        </div>
                        <div class="detail-2 d-flex-justify-content-start">
                            <div class="date"><?php echo e($item->created_at->diffForHumans()); ?></div>
                            <div class="budget"><?php echo e($item->rJobSalaryRange->name); ?></div>
                            <?php if(date('Y-m-d') > $item->deadline): ?>
                            <div class="expired">Expired</div>
                            <?php endif; ?>
                        </div>
                        <div class="special d-flex justify-content-start">
                            <?php if($item->is_featured == 1): ?><div class="featured">Featured</div> <?php endif; ?>
                            <div class="type"><?php echo e($item->rJobType->name); ?></div>
                            <?php if($item->is_urgent == 1): ?><div class="urgent">Urgent</div> <?php endif; ?>
                        </div>
                        <div class="bookmark">
                            <a href=""><i class="fas fa-bookmark active"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="all"><a href="<?php echo e(route('job_listing')); ?>" class="btn btn-primary">See All Jobs</a></div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($home_page_data->testimonial_status == 'Show'): ?>
<div class="testimonial" style="background-image: url(<?php echo e(asset('uploads/banner11.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="main-header">Our Happy Clients</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="testimonial-carousel owl-carousel">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="photo">
                            <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" alt="">
                        </div>
                        <div class="text">
                            <h4><?php echo e($item->name); ?></h4>
                            <p><?php echo e($item->designation); ?></p>
                        </div>
                        <div class="description"><?php echo e(nl2br($item->comment)); ?></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($home_page_data->blog_status == 'Show'): ?>
<div class="blog">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading">
                    <h2><?php echo e($home_page_data->blog_heading); ?></h2>
                    <p><?php echo e($home_page_data->blog_subheading); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="item">
                    <div class="photo">
                        <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" alt="<?php echo e($item->title); ?>">
                    </div>
                    <div class="text">
                        <h2>
                            <a href="<?php echo e(route('post', $item->slug)); ?>">
                                <?php echo e($item->title); ?>

                            </a>
                        </h2>
                        <div class="short-des">
                            <p><?php echo e($item->short_description); ?></p>
                        </div>
                        <div class="button">
                            <a href="<?php echo e(route('post', $item->slug)); ?>" class="btn btn-primary">
                                Read More
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/home.blade.php ENDPATH**/ ?>