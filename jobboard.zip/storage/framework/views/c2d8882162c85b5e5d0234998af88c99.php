

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . $global_banner_data->banner_company_panel)); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Video</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <div class="row">
                    <h4>Add Video</h4>
                    <form action="<?php echo e(route('company_videos_submit')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <input type="text" class="form-control" name="video_id" placeholder="Enter Video Code">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-sm" value="Submit">
                            </div>
                        </div>
                    </form>
                    <h4 class="mt-4">Existing Videos</h4>
                    <div class="video-all">
                        <?php if($videos->count() == 0): ?>
                        <div class="row">
                            <div class="col-md-12 text-danger">No Video Found</div>
                        </div>
                        <?php endif; ?>
                        <div class="row">
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-3">
                                    <div class="item">
                                        <a href="https://www.youtube.com/watch?v=<?php echo e($item->video_id); ?>" class="video-button">
                                            <img src="https://img.youtube.com/vi/<?php echo e($item->video_id); ?>/0.jpg" alt="Company Video" class="w-100">
                                            <div class="icon"><i class="far fa-play-circle"></i></div>
                                            <div class="bg"></div>
                                        </a>
                                    </div>
                                    <a href="<?php echo e(route('company_videos_delete', $item->id)); ?>" class="btn btn-danger btn-sm mb-4" onClick="return confirm('Are you sure?');">Delete</a>
                                </div>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/videos.blade.php ENDPATH**/ ?>