

<?php $__env->startSection('heading', 'Settings'); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin_settings_update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label>Existing logo</label>
                            <div><img src="<?php echo e(asset('uploads/' . $settings?->logo)); ?>" alt="" class="" style="width:150px"></div>
                        </div>
                        <div class="form-group mb-3">
                            <label>Change logo *</label>
                            <input type="file" class="form-control" name="logo">
                        </div>

                        <div class="form-group mb-3">
                            <label>Existing Favicon</label>
                            <div><img src="<?php echo e(asset('uploads/' . $settings?->favicon)); ?>" alt="" class="" style="width:50px"></div>
                        </div>
                        <div class="form-group mb-3">
                            <label>Change Favion</label>
                            <input type="file" class="form-control" name="favicon">
                        </div>

                        <div class="form-group mb-3">
                            <label>Top Bar Phone</label>
                            <input type="text" class="form-control" name="top_bar_phone" value="<?php echo e($settings?->top_bar_phone); ?>">
                        </div>
                        
                        <div class="form-group mb-3">
                            <label>Top Bar Email</label>
                            <input type="text" class="form-control" name="top_bar_email" value="<?php echo e($settings?->top_bar_email); ?>">
                        </div>
                        
                        <div class="form-group mb-3">
                            <label>Footer Phone</label>
                            <input type="text" class="form-control" name="footer_phone" value="<?php echo e($settings?->footer_phone); ?>">
                        </div>                        
                        <div class="form-group mb-3">
                            <label>Footer Email</label>
                            <input type="text" class="form-control" name="footer_email" value="<?php echo e($settings?->footer_email); ?>">
                        </div>                        
                        <div class="form-group mb-3">
                            <label>Footer Address</label>
                            <input type="text" class="form-control" name="footer_address" value="<?php echo e($settings?->footer_address); ?>">
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3">
                                <label>Facebook</label>
                                <input type="text" class="form-control" name="facebook" value="<?php echo e($settings?->facebook); ?>">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label>Twitter</label>
                                <input type="text" class="form-control" name="twitter" value="<?php echo e($settings?->twitter); ?>">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label>Pinterest</label>
                                <input type="text" class="form-control" name="pinterest" value="<?php echo e($settings?->pinterest); ?>">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label>Linkedin</label>
                                <input type="text" class="form-control" name="linkedin" value="<?php echo e($settings?->linkedin); ?>">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label>Instagram</label>
                                <input type="text" class="form-control" name="instagram" value="<?php echo e($settings?->instagram); ?>">
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label>Copyright Text</label>
                            <input type="text" class="form-control" name="copyright_text" value="<?php echo e($settings?->copyright_text); ?>">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/settings.blade.php ENDPATH**/ ?>