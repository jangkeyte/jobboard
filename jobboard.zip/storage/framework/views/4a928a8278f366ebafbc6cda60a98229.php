

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Photo</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <div class="row">
                    <h4>Add Photo</h4>
                    <form action="<?php echo e(route('company_photos_submit')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <input type="file" name="photo">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-sm" value="Submit">
                            </div>
                        </div>
                    </form>
                    <h4 class="mt-4">Existing Photos</h4>
                    <div class="photo-all">
                        <?php if($photos->count() == 0): ?>
                        <div class="row">
                            <div class="col-md-12 text-danger">No Photo Found</div>
                        </div>
                        <?php endif; ?>
                        <div class="row">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-3">
                                    <div class="item">
                                        <a href="<?php echo e(asset('uploads/' . $item->photo)); ?>" class="magnific">
                                            <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" alt="Company Photo" class="w-100">
                                            <div class="icon"><i class="fas fa-plus"></i></div>
                                            <div class="bg"></div>
                                        </a>
                                    </div>
                                    <a href="<?php echo e(route('company_photos_delete', $item->id)); ?>" class="btn btn-danger btn-sm mb-4" onClick="return confirm('Are you sure?');">Delete</a>
                                </div>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/photos.blade.php ENDPATH**/ ?>