<ul class="list-group list-group-flush">
    <li class="list-group-item <?php echo e(Route::is('candidate_dashboard') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_dashboard')); ?>">Dashboard</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_apply_view') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_apply_view')); ?>">Applied Jobs</a></li>
    <li class="list-group-item <?php echo e(Route::is('candidate_bookmark_view') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_bookmark_view')); ?>">Bookmarked Jobs</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_education') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_education')); ?>">Education</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_skill') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_skill')); ?>">Skills</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_work_experience') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_work_experience')); ?>">Work Experience</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_award') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_award')); ?>">Awards</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_edit_profile') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_edit_profile')); ?>">Edit Profile</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_edit_password') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_edit_password')); ?>">Change Password</a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('candidate_resume') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('candidate_resume')); ?>">Resume Upload</a>
    </li>
    <li class="list-group-item">
        <a href="<?php echo e(route('candidate_logout')); ?>">Logout</a></li>
</ul><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/candidate/sidebar.blade.php ENDPATH**/ ?>