<ul class="list-group list-group-flush">
    <li class="list-group-item <?php echo e(Route::is('company_dashboard') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_make_payment') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_make_payment')); ?>"><?php echo e(__('Make Payment')); ?></a></li>
    <li class="list-group-item <?php echo e(Route::is('company_orders') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_orders')); ?>"><?php echo e(__('Orders')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_jobs_create') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_jobs_create')); ?>"><?php echo e(__('Create Job')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_jobs') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_jobs')); ?>"><?php echo e(__('All Jobs')); ?></a>
    </li>
    <li class="list-group-item">
        <a href="<?php echo e(route('company_candidate_listing')); ?>"><?php echo e(__('Find Candidate')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_photos') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_photos')); ?>"><?php echo e(__('Photos')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_videos') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_videos')); ?>"><?php echo e(__('Videos')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_candidate_applications') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_candidate_applications')); ?>"><?php echo e(__('Candidate Applications')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_edit_profile') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_edit_profile')); ?>"><?php echo e(__('Edit Profile')); ?></a>
    </li>
    <li class="list-group-item <?php echo e(Route::is('company_edit_password') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('company_edit_password')); ?>"><?php echo e(__('Change Password')); ?></a>
    </li>
    <li class="list-group-item">
        <a href="<?php echo e(route('company_logout')); ?>"><?php echo e(__('Logout')); ?></a></li>
</ul><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/sidebar.blade.php ENDPATH**/ ?>