

<?php $__env->startSection('heading', 'Advertisement'); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin_advertisement_update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-primary mb-4">
                                    <div class="card-header">
                                        <div class="card-title"><?php echo e(__('Job Listing Ad')); ?></div>
                                        <div class="card-tools"> <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse"> <i data-lte-icon="expand" class="bi bi-plus-lg"></i> <i data-lte-icon="collapse" class="bi bi-dash-lg"></i> </button> </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group mb-4">
                                            <label><?php echo e(__('Existing Job Listing Ad')); ?></label>
                                            <div><img src="<?php echo e(asset('uploads/' . ($advertisement_data->job_listing_ad ?? 'background_default.jpg') )); ?>" alt="" class="w-50"></div>
                                        </div>               
                                        <div class="form-group mb-4">
                                            <label><?php echo e(__('Change Job Listing Ad')); ?></label>
                                            <div class="input-group mb-3">
                                                <input type="file" class="form-control" name="job_listing_ad">
                                                <label class="input-group-text"><?php echo e(__('Upload')); ?></label>
                                            </div>
                                        </div>  
                                        <div class="form-group mb-3">
                                            <label><?php echo e(__('Url')); ?> *</label>
                                            <input type="text" class="form-control" name="job_listing_ad_url" value="<?php echo e($advertisement_data?->job_listing_ad_url); ?>">
                                        </div>
                                        <div class="form-group mb-4">
                                            <label><?php echo e(__('Status')); ?></label>
                                            <select name="job_listing_ad_status" class="form-control select2">
                                                <option value="Show" <?php if($advertisement_data?->job_listing_ad_status == 'Show'): ?> selected <?php endif; ?>)><?php echo e(__('Show')); ?></option>
                                                <option value="Hide" <?php if($advertisement_data?->job_listing_ad_status == 'Hide'): ?> selected <?php endif; ?>><?php echo e(__('Hide')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-primary mb-4">
                                    <div class="card-header">
                                        <div class="card-title"><?php echo e(__('Company Listing Ad')); ?></div>
                                        <div class="card-tools"> <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse"> <i data-lte-icon="expand" class="bi bi-plus-lg"></i> <i data-lte-icon="collapse" class="bi bi-dash-lg"></i> </button> </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group mb-4">
                                            <label><?php echo e(__('Existing Company Listing Ad')); ?></label>
                                            <div><img src="<?php echo e(asset('uploads/' . ($advertisement_data->company_listing_ad ?? 'background_default.jpg') )); ?>" alt="" class="w-50"></div>
                                        </div>               
                                        <div class="form-group mb-4">
                                            <label><?php echo e(__('Change Company Listing Ad')); ?></label>
                                            <div class="input-group mb-3">
                                                <input type="file" class="form-control" name="company_listing_ad">
                                                <label class="input-group-text"><?php echo e(__('Upload')); ?></label>
                                            </div>
                                        </div>  
                                        <div class="form-group mb-3">
                                            <label><?php echo e(__('Url')); ?> *</label>
                                            <input type="text" class="form-control" name="company_listing_ad_url" value="<?php echo e($advertisement_data?->company_listing_ad_url); ?>">
                                        </div>
                                        <div class="form-group mb-4">
                                            <label><?php echo e(__('Status')); ?></label>
                                            <select name="company_listing_ad_status" class="form-control select2">
                                                <option value="Show" <?php if($advertisement_data?->company_listing_ad_status == 'Show'): ?> selected <?php endif; ?>)><?php echo e(__('Show')); ?></option>
                                                <option value="Hide" <?php if($advertisement_data?->company_listing_ad_status == 'Hide'): ?> selected <?php endif; ?>><?php echo e(__('Hide')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/advertisement.blade.php ENDPATH**/ ?>