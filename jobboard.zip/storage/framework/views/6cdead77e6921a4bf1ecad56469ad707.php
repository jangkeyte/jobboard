<form action="<?php echo e(url('candidate-listing')); ?>" method="get">
    <div class="accordion" id="accordion">
        <div class="accordion-item shadow mt-3"> 
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#Candidate_Title" aria-expanded="true" aria-controls="Candidate_Title">
                <?php echo e(__('Candidate Skill')); ?>

            </button>
            </h2>
            <div id="Candidate_Skill" class="accordion-collapse collapse show">
                <div class="accordion-body">
                    <div class="job-filter fs-7">
                        <div class="widget">
                            <input type="text" class="form-control fs-7" name="title" value="<?php echo e($form_data->name); ?>" placeholder="<?php echo e(__('Skill Name')); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#CandidateJobCategory" aria-expanded="true" aria-controls="CandidateJobCategory">
                <?php echo e(__('Candidate Sector')); ?>

            </button>
            </h2>
            <div id="CandidateJobCategory" class="accordion-collapse collapse show">
                <div class="accordion-body">
                    <div class="job-filter fs-7">
                        <?php $__currentLoopData = $candidate_sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check py-1">
                                <input class="form-check-input" type="radio" name="candidate_sectors" id="candidate_sectors<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" <?php if($form_data->sector_id == $item->id): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="candidate_sectors<?php echo e($item->id); ?>">
                                    <?php echo e($item->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="filter-button mt-3">
        <button type="submit" class="btn btn-danger w-100 rounded-0 py-2">
            <i class="fas fa-search pe-2"></i> <?php echo e($home_page_data->search ?? __('Filter')); ?>

        </button>
    </div>

</form>

<?php if($advertisement_data && $advertisement_data->candidate_listing_ad_status == 'Show'): ?>
    <div class="advertisement">
        <?php if($advertisement_data->candidate_listing_ad_url == null): ?>
            <img src="<?php echo e(asset('uploads/' . $advertisement_data->candidate_listing_ad)); ?>" alt="" class="w-100">
        <?php else: ?>
            <a href="<?php echo e($advertisement_data->candidate_listing_ad_url); ?>" target="_blank"><img src="<?php echo e(asset('uploads/' . $advertisement_data->candidate_listing_ad)); ?>" alt="" class="w-100"></a>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/candidate_listing_search_form.blade.php ENDPATH**/ ?>