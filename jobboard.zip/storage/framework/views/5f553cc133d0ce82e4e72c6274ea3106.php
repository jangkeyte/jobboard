

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . $global_banner_data->banner_candidate_panel)); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e(__('Dashboard')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('candidate.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <h3>Hello, <?php echo e(Auth::guard('candidate')->user()->name); ?></h3>
                <p>See all the statistics at a glance:</p>

                <div class="row box-items">
                    <div class="col-md-4">
                        <div class="box1">
                            <h4><?php echo e($total_applied_jobs); ?></h4>
                            <p>Applied Jobs</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box1">
                            <h4><?php echo e($total_rejected_jobs); ?></h4>
                            <p>Rejected Jobs</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box1">
                            <h4><?php echo e($total_approved_jobs); ?></h4>
                            <p>Approved Jobs</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/candidate/dashboard.blade.php ENDPATH**/ ?>