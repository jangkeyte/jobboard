

<?php $__env->startSection('seo_title'); ?><?php echo e($job_category_page_item->title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($job_category_page_item->meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_job_categories ?? 'default_banner.jpg'))); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($job_category_page_item->heading ?? __('SEO Heading')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="job-category">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="item">
                    <div class="icon">
                        <i class="<?php echo e($item->icon); ?>"></i>
                    </div>
                    <h3><a href="<?php echo e(url('job-listing?category=' . $item->id)); ?>"><?php echo e($item->name); ?></a></h3>
                    <p>(<?php echo e($item->r_job_count); ?> Open Positions)</p>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/job_categories.blade.php ENDPATH**/ ?>