<div class="page-top my-2" style="background-image: url(<?php echo e(asset('uploads/' . ($background_image ?? 'default.png'))); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($heading_text ?? __('Heading')); ?></h2>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/templates/page_heading.blade.php ENDPATH**/ ?>