

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . $global_banner_data->banner_company_panel)); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Candidate Applications</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">                
                <h3>Applicants for <?php echo e($job_single->title); ?></h3>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Status</th>
                                <th>Action</th>
                                <th>Detail</th>
                                <th>CV</th>
                            </tr>
                            
                            <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->rCandidate->name); ?></td>
                                <td><?php echo e($item->rCandidate->email); ?></td>
                                <td><?php echo e($item->rCandidate->phone); ?></td>
                                <td>
                                    <?php if($item->status == 'Applied'): ?>
                                        <?php $color="primary"; ?>
                                    <?php elseif($item->status == 'Approved'): ?>
                                        <?php $color="success"; ?>
                                    <?php elseif($item->status == 'Rejected'): ?>
                                        <?php $color="danger"; ?>
                                    <?php else: ?>
                                        <?php $color="warning"; ?>
                                    <?php endif; ?>
                                    <span class="badge bg-<?php echo e($color); ?>"><?php echo e($item->status); ?></span>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('company_applicant_status_change', $item->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="job_id" value="<?php echo e($job_single->id); ?>">
                                        <input type="hidden" name="candidate_id" value="<?php echo e($item->candidate_id); ?>">
                                        <select name="status" class="form-control select2" onchange="this.form.submit()">
                                            <option value="">Select</option>
                                            <option value="Applied">Apply</option>
                                            <option value="Approved">Approve</option>
                                            <option value="Rejected">Reject</option>
                                        </select>
                                    </form>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('company_applicant_resume', $item->candidate_id)); ?>" title="Candidate Detail"><i class="bi bi-eye"></i></a>
                                    <a href="" data-bs-toggle="modal" data-bs-target="#coverLetterModal<?php echo e($item->id); ?>" title="Cover Letter"><i class="bi bi-envelope"></i></a>
                            </td>
                            </tr>

                            <!-- Modal -->
                            <div class="modal fade" id="coverLetterModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="coverLetterModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="coverLetterModalLabel">Cover Letter for Job <?php echo e($item->rJob->title); ?> of <?php echo e($item->rJob->rCompany->company_name); ?> Company</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php echo nl2br($item->cover_letter); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/applicants.blade.php ENDPATH**/ ?>