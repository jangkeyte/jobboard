

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . $global_banner_data->banner_candidate_panel)); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Applications Job</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('candidate.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">
                <?php if(!$application_jobs->count()): ?>
                    <div class="text-danger">No data found</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>SL</th>
                                <th>Job Title</th>
                                <th>Company</th>
                                <th>Status</th>
                                <th>Cover Letter</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $application_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->rJob->title); ?></td>
                                <td><?php echo e($item->rJob->rCompany->company_name); ?></td>
                                <td>
                                    <?php switch($item->status):
                                        case ('Approved'): ?>
                                            <?php $color = 'success'; ?>
                                            <?php break; ?>
                                        <?php case ('Rejected'): ?>
                                            <?php $color = 'danger'; ?>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <?php $color = 'primary'; ?>
                                    <?php endswitch; ?>
                                    <div class="badge bg-<?php echo e($color); ?>"><?php echo e($item->status); ?></div>
                                </td>
                                <td><a href="" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#coverLetterModal<?php echo e($item->id); ?>">Cover Letter</a></td>
                                <td>
                                    <a href="<?php echo e(route('job', $item->job_id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('candidate_apply_delete', $item->id)); ?>" class="btn btn-danger btn-sm" onClick="return confirm('Are you sure?');"><i class="fas fa-trash-alt"></i></aa>
                                </td>
                            </tr>
                            
                            <!-- Modal -->
                            <div class="modal fade" id="coverLetterModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="coverLetterModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="coverLetterModalLabel">Cover Letter for Job <?php echo e($item->rJob->title); ?> of <?php echo e($item->rJob->rCompany->company_name); ?> Company</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php echo nl2br($item->cover_letter); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/candidate/applications.blade.php ENDPATH**/ ?>