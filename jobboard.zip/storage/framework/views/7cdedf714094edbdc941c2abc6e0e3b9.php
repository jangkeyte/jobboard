

<?php $__env->startSection('seo_title'); ?><?php echo e($other_page_item->company_listing_page_title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($other_page_item->job_listing_page_meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<?php if(isset($company_single)): ?>
<div class="page-top-detail" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_job_detail ?? 'banner_default.jpg'))); ?>)"></div>
<div class="container w-75 bg-white" style="margin-top: -150px;">
    <div class="row py-5 border">
        <div class="col-md-12">
            <div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 job job-single">
                            <div class="item d-flex justify-content-start">
                                <div class="logo job-detail-image me-4">
                                    <?php echo $__env->make('front/templates/image', array('image' => $company_single->logo, 'name' => $company_single->company_name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <div class="text mt-4">
                                    <h4 class="text-black fw-bold"><?php echo e($company_single->company_name); ?></h4>
                                    <div class="pt-2">
                                        <i class="pe-1 fa fa-location-dot"></i><?php echo e($company_single->rCompanyLocation->name); ?>

                                        <a 
                                            href="https://www.google.com/maps/search/<?php echo e(__('company')); ?> <?php echo e($company_single->company_name); ?> <?php echo e(__('in')); ?> <?php echo e($company_single->rCompanyLocation->name); ?>"
                                            class="btn btn-danger rounded-4 ms-2 fs-8 py-0" style="height:20px;"
                                        >
                                            <?php echo e(__('view on map')); ?>

                                        </a>
                                    </div>
                                    
                                    <div class="pt-3">
                                            <span>
                                                <a 
                                                    href="<?php echo e(route('candidate_apply', $company_single->id)); ?>"
                                                    class="btn btn-outline hover-danger rounded-1 btn-follow me-2"
                                                    style="padding-top:6px;"
                                                >
                                                    <i class="pe-2 fa fa-plus"></i><?php echo e(__('Add a review')); ?>

                                                </a>
                                                <a 
                                                    href="<?php echo e(route('candidate_bookmark_add', $company_single->id)); ?>" 
                                                    class="btn btn-outline hover-danger rounded-1 btn-follow me-2"
                                                    style="padding-top:6px;"
                                                >
                                                    <i class="fa fa-user-plus pe-2"></i><?php echo e(__('Follow')); ?>

                                                </a>

                                                <span class="px-2 fs-7"><?php echo e(__('SOCIAL LINK:')); ?></span>
                                                
                                                <?php if($company_single->facebook != ''): ?>
                                                    <a href="<?php echo e($company_single->facebook); ?>" target="_blank"><i class="px-1 fa-brands fa-facebook fa-lg hover-color-danger" style="color:#3b5998;"></i></a>
                                                <?php endif; ?>
                                                <?php if($company_single->twitter != ''): ?>
                                                    <a href="<?php echo e($company_single->twitter); ?>" target="_blank"><i class="px-1 fa-brands fa-twitter fa-lg hover-color-danger" style="color:#3ac1f1;"></i></a>
                                                <?php endif; ?>
                                                <?php if($company_single->linkedin != ''): ?>
                                                    <a href="<?php echo e($company_single->linkedin); ?>" target="_blank"><i class="px-1 fa-brands fa-linkedin fa-lg hover-color-danger" style="color:#007AB9;"></i></a>
                                                <?php endif; ?>
                                                <?php if($company_single->instagram != ''): ?>
                                                    <a href="<?php echo e($company_single->instagram); ?>" target="_blank"><i class="px-1 fa-brands fa-square-instagram fa-lg hover-color-danger" style="color:#f95c94"></i></a>
                                                <?php endif; ?>
                                            </span>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-8 pe-3 ps-0 float-left">
            <div class="job-result pt-4 pb-5 px-4 border">
                <div class="left-item">
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Job Detail')); ?></span></div>
                    <div class="container">

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-calendar-days fs-1 text-danger"></i></div>
                                    <div class="col-md-9 px-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Founded Since')); ?></div>
                                            <div class="col-md-12"><?php echo e($company_single->founded_on); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-folder fs-1 text-danger"></i></div>
                                    <div class="col-md-9 pe-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Sectors')); ?></div>
                                            <div class="col-md-12"><?php echo e($company_single->rCompanyIndustry->name); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-briefcase fs-1 text-danger"></i></div>
                                    <div class="col-md-9 px-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Posted Jobs')); ?></div>
                                            <div class="col-md-12"><?php echo e($jobs->count()); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="left-item">                                
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Company Description')); ?></span></div>
                    <p><?php echo $company_single->description; ?></p>
                </div>
  
                
                <div class="left-item">
                    <div class="py-3 "><span class="fs-4 fw-bolder"><?php echo e(__('Open Positions')); ?></span></div>
                    
                    <div class="job related-job pt-0 pb-0">
                        <div class="container">
                            <div class="row">

                                <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $this_company_id = $item->rCompany->id;
                                        $order_data = \App\Models\Order::where('company_id', $this_company_id)->where('currently_active', 1)->first();
                                        if(date('Y-m-d') > $order_data?->expire_date) {
                                            continue;
                                        }
                                    ?>

                                    <div class="col-md-12 py-2">
                                        <div class="row border">
                                            <div class="col-md-1 pt-4">
                                                <div class="border">
                                                    <a href="<?php echo e(route('job', $item->id)); ?>" data-job-id="174" class="">
                                                        <?php echo $__env->make('front/templates/image', array('image' => $item->rCompany->logo, 'name' => $item->rCompany->company_name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-md-9 pt-3">
                                                <div>
                                                    <h5><a class="fw-bold" href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?></a></h5>
                                                    <ul class="list-unstyled fs-7">
                                                        <li>
                                                                <a class ="text-danger" href="<?php echo e(route('company', $item->rCompany->id)); ?>"><?php echo e('@ ' . $item->rCompany->company_name); ?></a>
                                                                <i class="ms-1 px-1 border-start fa fa-location-dot"></i><a href="<?php echo e(url('/job-listing?location=' . $item->rJobLocation->id)); ?>" title="<?php echo e(__('Find job by location in ') . $item->rJobLocation->name); ?>"><?php echo e($item->rJobLocation->name); ?></a>
                                                                <?php if($item->is_featured == 1): ?><div class="featured badge text-bg-primary"><?php echo e(__('Featured')); ?></div> <?php endif; ?>
                                                                <?php if($item->is_urgent == 1): ?><div class="urgent badge text-bg-danger"><?php echo e(__('Urgent')); ?></div> <?php endif; ?>
                                                        </li>
                                                        <li>
                                                            <i class="px-1 fa fa-calendar-days"></i>Published <?php echo e($item->created_at->diffForHumans()); ?>

                                                            <?php if(date('Y-m-d') > $item->deadline): ?>
                                                                <div class="expired badge text-bg-warning"><?php echo e(__('Expired')); ?></div>
                                                            <?php endif; ?>
                                                            <i class="ms-1 px-1 border-start fa fa-filter"></i><a href="<?php echo e(url('/job-listing?category=' . $item->rJobCategory->id)); ?>" title="<?php echo e(__('Find job by category of ') . $item->rJobCategory->name); ?>"><?php echo e($item->rJobCategory->name); ?></a>
                                                            <i class="ms-1 px-1 border-start fa fa-dollar-sign"></i><?php echo e($item->rJobSalaryRange->name); ?>

                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="col-md-2 pt-5 px-0">
                                                <ul class="list-unstyled fs-7">
                                                    <li>
                                                        <?php if($item->rJobType->id == 1): ?><button type="submit" class="btn btn-fulltime rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 2): ?><button type="submit" class="btn btn-parttime rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 3): ?><button type="submit" class="btn btn-freelance rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 4): ?><button type="submit" class="btn btn-temporary rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 5): ?><button type="submit" class="btn btn-internship rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        
                                                        <?php if(!Auth::guard('company')->check()): ?>
                                                            <?php if(Auth::guard('candidate')->check()): ?>
                                                                <?php
                                                                    $count = \App\Models\CandidateBookmark::where('candidate_id', Auth::guard('candidate')->user()->id)->where('job_id', $item->id)->count();
                                                                    if($count > 0) {
                                                                        $bookmark_status = 'bg-danger';
                                                                    } else {
                                                                        $bookmark_status = '';
                                                                    }
                                                                ?>
                                                            <?php else: ?>
                                                                <?php $bookmark_status = ''; ?>
                                                            <?php endif; ?>
                                                            <a class="icon-job-like bg-danger pt-1" href="<?php echo e(route('candidate_bookmark_add', $item->id)); ?>"><i class="fa fa-heart"></i></a>
                                                        <?php endif; ?>
                                                        
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                
                                    <div class="text-danger">No related job found.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 ps-3 pe-0 float-right">
            <div class="container">
                <form action="<?php echo e(route('company_enquery_email')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-2">
                        <div class="col-md-12 p-0">
                            <span class="fs-5 fw-bolder text-black"><?php echo e(__('Contact Form')); ?></span>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12 p-4 border">
                            <input type="hidden" name="company_email" value="<?php echo e($company_single->email); ?>">
                            <?php echo e(__('User Name')); ?>

                            <div class="mb-3 mt-2">
                                <input type="text" class="form-control" name="visitor_name" placeholder="Enter Your Name">
                            </div>
                            <?php echo e(__('Email Address')); ?>

                            <div class="mb-3 mt-2">
                                <input type="text" class="form-control" name="visitor_email" placeholder="Enter Your Email Address">
                            </div>
                            <?php echo e(__('Phone Number')); ?>

                            <div class="mb-3 mt-2">
                                <input type="text" class="form-control" name="visitor_phone" placeholder="Enter Your Phone Number">
                            </div>
                            <?php echo e(__('Message')); ?>

                            <div class="mb-3 mt-2">
                                <textarea class="form-control" name="visitor_message" placeholder="Enter Your Message Here" rows="5" style="width: 100%;" ></textarea>
                            </div>
                            <button type="submit" class="btn btn-danger w-100 py-2"><?php echo e(__('SEND NOW')); ?></button>
                        </div>
                    </div>
                    
                </form>
                
                <!-- <?php if($company_single->map_code != null): ?>
                    <div class="row border mt-4">
                    <div class="right-item">
                        <h2><i class="fas fa-file-invoice"></i> Location Map</h2>
                        <div class="location-map">
                            <?php echo nl2br($company_single->map_code); ?>

                        </div>
                    </div>
                    </div>
                <?php endif; ?> -->
                
            </div>
        </div>

    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/company.blade.php ENDPATH**/ ?>