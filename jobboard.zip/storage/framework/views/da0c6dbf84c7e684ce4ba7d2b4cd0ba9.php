<?php if(isset($image) && file_exists(public_path() . '/uploads/' . $image)): ?>
    <img src="<?php echo e(asset('uploads/' . $image)); ?>" alt="<?php echo e($name ?? ''); ?>" <?php if(isset($class)): ?> class="<?php echo e($class); ?>" <?php endif; ?>>
<?php else: ?>
    <img src="<?php echo e(asset('assets/images/default.jpg')); ?>" alt="<?php echo e($name ?? ''); ?>">
<?php endif; ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/image.blade.php ENDPATH**/ ?>