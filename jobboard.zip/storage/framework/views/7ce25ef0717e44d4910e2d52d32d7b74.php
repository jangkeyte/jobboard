

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Job Title</h2>
            </div>
        </div>
    </div>
</div>

<div class="page-top page-top-job-single" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 job job-single">
                <div class="item d-flex justify-content-start">
                    <div class="logo"><img src="<?php echo e(asset('uploads/' . $job_single->rCompany->logo)); ?>"></div>
                    <div class="text">
                        <h3><?php echo e($job_single->title); ?>, <?php echo e($job_single->rCompany->company_name); ?></h3>
                        <div class="detail-1 d-flex justify-content-start">
                            <div class="category"><?php echo e($job_single->rJobCategory->name); ?></div>
                            <div class="location"><?php echo e($job_single->rJobLocation->name); ?></div>
                        </div>
                        <div class="detail-2 d-flex-justify-content-start">
                            <div class="date"><?php echo e($job_single->created_at->diffForHumans()); ?></div>
                            <div class="budget"><?php echo e($job_single->rJobSalaryRange->name); ?></div>
                            <?php if(date('Y-m-d') > $job_single->deadline): ?>
                            <div class="expired">Expired</div>
                            <?php endif; ?>
                        </div>
                        <div class="special d-flex justify-content-start">
                            <?php if($job_single->is_featured == 1): ?><div class="featured">Featured</div> <?php endif; ?>
                            <div class="type"><?php echo e($job_single->rJobType->name); ?></div>
                            <?php if($job_single->is_urgent == 1): ?><div class="urgent">Urgent</div> <?php endif; ?>
                        </div>
                        <div class="apply">
                            <?php if(date('Y-m-d') >= $job_single->deadline): ?>
                            <a href="" class="btn btn-primary">Apply Now</a>
                            <a href="" class="btn btn-primary save-job">Bookmark</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="job-result pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Description</h2>
                    <p><?php echo $job_single->description; ?></p>
                </div>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Job Responsibilities</h2>
                    <?php echo nl2br($job_single->responsibility); ?>

                </div>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Skills and Abilities</h2>
                    <?php echo nl2br($job_single->skill); ?>

                </div>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Educational Qualification</h2>
                    <?php echo nl2br($job_single->education); ?>

                </div>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Benefits</h2>
                    <?php echo nl2br($job_single->benefit); ?>

                </div>
                <?php if(date('Y-m-d') >= $job_single->deadline): ?>
                <div class="left-item">
                    <div class="apply">
                        <a href="" class="btn btn-primary">Apply Now</a>
                    </div>
                </div>
                <?php endif; ?>
                <div class="left-item">
                    <h2><i class="fas fa-file-invoice"></i> Related Jobs</h2>
                    <div class="job related-job pt-0 pb-0">
                        <div class="container">
                            <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $jobs_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-md-12">
                                        <div class="item d-flex justify-content-start">
                                            <div class="logo">
                                                <img src="<?php echo e(asset('uploads/' . $item->rCompany->logo)); ?>" alt="<?php echo e($item->rCompany->company_name); ?>">
                                            </div>
                                            <div class="text">
                                                <h3>
                                                    <a href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?>, <?php echo e($item->rCompany->company_name); ?></a>
                                                </h3>
                                                <div class="detail-1 d-flex justify-content-start">
                                                    <div class="category"><?php echo e($item->rJobCategory->name); ?></div>
                                                    <div class="location"><?php echo e($item->rJobLocation->name); ?></div>
                                                </div>
                                                <div class="detail-2 d-flex-justify-content-start">
                                                    <div class="date"><?php echo e($item->created_at->diffForHumans()); ?></div>
                                                    <div class="budget"><?php echo e($item->rJobSalaryRange->name); ?></div>
                                                    <?php if(date('Y-m-d') > $item->deadline): ?>
                                                    <div class="expired">Expired</div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="special d-flex justify-content-start">
                                                    <?php if($item->is_featured == 1): ?><div class="featured">Featured</div> <?php endif; ?>
                                                    <div class="type"><?php echo e($item->rJobType->name); ?></div>
                                                    <?php if($item->is_urgent == 1): ?><div class="urgent">Urgent</div> <?php endif; ?>
                                                </div>
                                                <div class="bookmark">
                                                    <a href=""><i class="fas fa-bookmark active"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                
                                    <div class="text-danger">No related job found.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="right-item">
                    <h2><i class="fas fa-file-invoice"></i> Job Summary</h2>
                    <div class="summary">
                        <div class="table-responsive">
                            <table class="rable table-bordered">
                                <tr>
                                    <td><b>Published On:</b></td>
                                    <td><?php echo e($job_single->created_at->format('d F, Y')); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Deadline:</b></td>
                                    <td><?php echo e(DateTime::createFromFormat('Y-m-d', $job_single->deadline)->format('d F, Y')); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Vacancy:</b></td>
                                    <td><?php echo e($job_single->vacancy); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Category:</b></td>
                                    <td><?php echo e($job_single->rJobCategory->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Location:</b></td>
                                    <td><?php echo e($job_single->rJobLocation->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Type:</b></td>
                                    <td><?php echo e($job_single->rJobType->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Experience:</b></td>
                                    <td><?php echo e($job_single->rJobExperience->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Gender:</b></td>
                                    <td><?php echo e($job_single->rJobGender->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Salary Range:</b></td>
                                    <td><?php echo e($job_single->rJobSalaryRange->name); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="right-item">
                    <h2><i class="fas fa-file-invoice"></i> Enquery Formy</h2>
                    <div class="enquery-form">
                        <form action="<?php echo e(route('job_enquery_email')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="job_title" value="<?php echo e($job_single->title); ?>">
                            <input type="hidden" name="company_email" value="<?php echo e($job_single->rCompany->email); ?>">
                            <div class="mb-3">
                                <input type="text" class="form-control" name="visitor_name" placeholder="Full Name">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" name="visitor_email" placeholder="Email Address">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" name="visitor_phone" placeholder="Phone Number">
                            </div>
                            <div class="mb-3">
                                <textarea name="visitor_message" cols="30" rows="10" placeholder="Message"></textarea>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <?php if($job_single->map_code != null): ?>
                <div class="right-item">
                    <h2><i class="fas fa-file-invoice"></i> Location Map</h2>
                    <div class="location-map">
                        <?php echo nl2br($job_single->map_code); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/job.blade.php ENDPATH**/ ?>