<form action="<?php echo e(url('job-listing')); ?>" method="get">
    <div class="accordion" id="accordion">
        <div class="accordion-item shadow mt-3"> 
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#JobTitle" aria-expanded="true" aria-controls="JobTitle">
                <?php echo e(__('Job Title')); ?>

            </button>
            </h2>
            <div id="JobTitle" class="accordion-collapse collapse show">
                <div class="accordion-body">
                    <div class="job-filter fs-7">
                        <div class="widget">
                            <input type="text" class="form-control fs-7" name="title" value="<?php echo e($form_data->title); ?>" placeholder="<?php echo e(__('Job Title')); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#JobCategory" aria-expanded="true" aria-controls="JobCategory">
                <?php echo e(__('Job Category')); ?>

            </button>
            </h2>
            <div id="JobCategory" class="accordion-collapse collapse">
                <div class="accordion-body">
                    <div class="job-filter fs-7">
                        <div>
                            <select name="category" class="form-control select2 fs-7">
                                <option value=""><?php echo e(__('Job Category')); ?></option>
                                <?php $__currentLoopData = $job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_data->job_category == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#JobLocation" aria-expanded="true" aria-controls="JobLocation">
                <?php echo e(__('Job Location')); ?>

            </button>
            </h2>
            <div id="JobLocation" class="accordion-collapse collapse">
                <div class="accordion-body">
                    <div class="job-filter fs-7">
                        <div class="widget">
                            <select name="location" class="form-control select2 fs-7">
                                <option value=""><?php echo e(__('Job Location')); ?></option>
                                <?php $__currentLoopData = $job_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_data->job_location_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#JobType" aria-expanded="true" aria-controls="JobType">
                <?php echo e(__('Job Type')); ?>

            </button>
            </h2>
            <div id="JobType" class="accordion-collapse collapse">
                <div class="accordion-body fs-7">
                    <?php $__currentLoopData = $job_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check py-1">
                            <input class="form-check-input" type="radio" name="job_types" id="job_types<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" <?php if($form_data->job_salary_range_id == $item->id): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="job_types<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#Experience" aria-expanded="true" aria-controls="Experience">
                <?php echo e(__('Experience')); ?>

            </button>
            </h2>
            <div id="Experience" class="accordion-collapse collapse">
                <div class="accordion-body fs-7">
                    <?php $__currentLoopData = $job_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check py-1">
                            <input class="form-check-input" type="radio" name="job_experiences" id="job_experiences<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" <?php if($form_data->job_salary_range_id == $item->id): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="job_experiences<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#Gender" aria-expanded="true" aria-controls="Gender">
                <?php echo e(__('Gender')); ?>

            </button>
            </h2>
            <div id="Gender" class="accordion-collapse collapse">
                <div class="accordion-body fs-7">
                    <?php $__currentLoopData = $job_genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check py-1">
                            <input class="form-check-input" type="radio" name="job_genders" id="job_genders<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" <?php if($form_data->job_salary_range_id == $item->id): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="job_genders<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="accordion-item shadow mt-3 ">
            <h2 class="accordion-header">
            <button class="accordion-button bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#SalaryRange" aria-expanded="true" aria-controls="SalaryRange">
                <?php echo e(__('Salary Range')); ?>

            </button>
            </h2>
            <div id="SalaryRange" class="accordion-collapse collapse">
                <div class="accordion-body fs-7">
                    <?php $__currentLoopData = $job_salary_ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check py-1">
                            <input class="form-check-input" type="radio" name="job_salary_ranges" id="job_salary<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" <?php if($form_data->job_salary_range_id == $item->id): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="job_salary<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>                        
    </div>

    <div class="filter-button mt-3">
        <button type="submit" class="btn btn-danger w-100 rounded-0 py-2">
            <i class="fas fa-search pe-2"></i> <?php echo e($home_page_data->search ?? __('Filter')); ?>

        </button>
    </div>

</form>

<?php if($advertisement_data && $advertisement_data->job_listing_ad_status == 'Show'): ?>
<div class="advertisement">                            
    <?php if($advertisement_data->job_listing_ad_url == null): ?>
        <img src="<?php echo e(asset('uploads/' . $advertisement_data->job_listing_ad)); ?>" alt="" class="w-100">
    <?php else: ?>
        <a href="<?php echo e($advertisement_data->job_listing_ad_url); ?>" target="_blank"><img src="<?php echo e(asset('uploads/' . $advertisement_data->job_listing_ad)); ?>" alt="" class="w-100"></a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/job_listing_search_form.blade.php ENDPATH**/ ?>