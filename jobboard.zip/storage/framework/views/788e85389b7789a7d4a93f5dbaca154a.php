<div class="careerfy-counter-elevenview">
    <ul class="row">
        <li class="col-md-3">
            <i class="careerfy-icon fa-solid fa-briefcase" style="color:#ff0000"></i>
            <h2>Jobs</h2>
            <span class="word-counter">8073</span>
        </li>
        <li class="col-md-3">
            <i class="careerfy-icon fa-solid fa-user-tie" style="color:#ff0000"></i>
            <h2>Members</h2>
            <span class="word-counter">5479</span>
        </li>
        <li class="col-md-3">
            <i class="careerfy-icon fa-solid fa-id-card" style="color:#ff0000"></i>
            <h2>Resume</h2>
            <span class="word-counter">6547</span>
        </li>
        <li class="col-md-3">
            <i class="careerfy-icon fa-solid fa-city" style="color:#ff0000"></i>
            <h2>Company</h2>
            <span class="word-counter">4512</span>
        </li>
    </ul>
</div>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/home_stats.blade.php ENDPATH**/ ?>