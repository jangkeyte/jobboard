<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <form class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
            <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="fas fa-search"></i></a></li>
        </ul>
    </form>
    <ul class="navbar-nav navbar-right w-100 justify-content-end">
        <li class="nav-link">
            <a href="<?php echo e(route('home')); ?>" target="_blank" class="btn btn-warning">Front End</a>
        </li>
        <li class="nav-item dropdown">
            <button class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <img alt="image" src="<?php echo e(asset('uploads/' . Auth::guard('admin')->user()->photo)); ?>" class="rounded-circle" style="width:50px">
                <div class="d-sm-none d-lg-inline-block"><?php echo e(Auth::guard('admin')->user()->name); ?></div>
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo route('admin_profile'); ?>"><i class="far fa-user"></i> Edit Profile</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin_logout')); ?>"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </li>
    </ul>
</nav><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/layout/nav.blade.php ENDPATH**/ ?>