

<?php $__env->startSection('seo_title'); ?><?php echo e($other_page_item->job_listing_page_title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($other_page_item->job_listing_page_meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top-detail" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_job_detail ?? 'banner_default.jpg'))); ?>)"></div>
<div class="container w-75 bg-white" style="margin-top: -150px;">
    <div class="row py-5 border">
        <div class="col-md-12">
            <div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 job job-single">
                            <div class="item d-flex justify-content-start">
                                <div class="logo job-detail-image me-4"><img src="<?php echo e(asset('uploads/' . $job_single->rCompany->logo)); ?>"></div>
                                <div class="text">
                                    <h4 class="text-black fw-bold"><?php echo e($job_single->title); ?></h4>
                                    <span>
                                        <?php if($job_single->rJobType->id == 1): ?><button type="submit" class="btn btn-fulltime rounded-0 btn-job-type"><?php echo e($job_single->rJobType->name); ?></button><?php endif; ?>
                                        <?php if($job_single->rJobType->id == 2): ?><button type="submit" class="btn btn-parttime rounded-0 btn-job-type"><?php echo e($job_single->rJobType->name); ?></button><?php endif; ?>
                                        <?php if($job_single->rJobType->id == 3): ?><button type="submit" class="btn btn-freelance rounded-0 btn-job-type"><?php echo e($job_single->rJobType->name); ?></button><?php endif; ?>
                                        <?php if($job_single->rJobType->id == 4): ?><button type="submit" class="btn btn-temporary rounded-0 btn-job-type"><?php echo e($job_single->rJobType->name); ?></button><?php endif; ?>
                                        <?php if($job_single->rJobType->id == 5): ?><button type="submit" class="btn btn-internship rounded-0 btn-job-type"><?php echo e($job_single->rJobType->name); ?></button><?php endif; ?>
                                        <a class ="text-black px-1 fw-bold" href="javascript:void(0);"><?php echo e($job_single->rCompany->company_name); ?></a>
                                        <span class ="text-danger fs-8 fst-italic pe-1" href="javascript:void(0);"><?php echo e(__('posted')); ?> <?php echo e($job_single->created_at->format('d F, Y')); ?> <?php echo e($job_single->created_at->diffForHumans()); ?></span> 
                                        <a class ="text-black fw-bold" href="javascript:void(0);"><?php echo e(__('in')); ?> <?php echo e($job_single->rJobCategory->name); ?></a>
                                    <span/>

                                    <div class="pt-2">
                                        <i class="pe-1 fa fa-location-dot"></i><?php echo e($job_single->rJobLocation->name); ?>

                                        <a 
                                            href="https://www.google.com/maps/search/<?php echo e(__('company')); ?> <?php echo e($job_single->rCompany->company_name); ?> <?php echo e(__('in')); ?> <?php echo e($job_single->rJobLocation->name); ?>"
                                            class="btn btn-danger rounded-4 ms-2 fs-8 py-0" style="height:20px;"
                                        >
                                            <?php echo e(__('view on map')); ?>

                                        </a>
                                    </div>

                                    <div class="pt-2">
                                        <i class="pe-1 fa fa-calendar-days text-danger"></i><?php echo e($job_single->created_at); ?>

                                        <i class="ps-4 pe-1 fa fa-calendar-days text-danger"></i><?php echo e($job_single->deadline); ?>

                                        <i class="ps-4 pe-1 fa fa-money-bill text-danger"></i><?php echo e($job_single->rJobSalaryRange->name); ?>

                                    </div>

                                    <div class="pt-2">
                                        <?php if($job_single->is_featured == 1): ?><div class="featured badge text-bg-primary"><?php echo e(__('Featured')); ?></div> <?php endif; ?>
                                        <?php if($job_single->is_urgent == 1): ?><div class="urgent badge text-bg-danger"><?php echo e(__('Urgent')); ?></div> <?php endif; ?>
                                        <?php if(date('Y-m-d') > $job_single->deadline): ?><div class="badge text-bg-warning"><?php echo e(__('Expired')); ?></div><?php endif; ?>
                                    </div>
                                    
                                    <?php if(!Auth::guard('company')->check()): ?>
                                    <div class="pt-3">
                                        <?php if(date('Y-m-d') >= $job_single->deadline): ?>
                                            <a href="<?php echo e(route('candidate_apply', $job_single->id)); ?>" class="btn btn-danger me-2">
                                                <i class="pe-2 fa fa-feather-pointed"></i><?php echo e(__('Apply Now')); ?>

                                            </a>
                                            <a href="<?php echo e(route('candidate_bookmark_add', $job_single->id)); ?>" class="btn btn-warning save-job">
                                                <i class="pe-2 fa fa-bookmark"></i><?php echo e(__('Bookmark')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-8 pe-3 ps-0 float-left">
            <div class="job-result pt-4 pb-5 px-4 border">
                <div class="left-item">
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Job Detail')); ?></span></div>
                    <div class="container">

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-briefcase fs-1 text-danger"></i></div>
                                    <div class="col-md-9 px-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Job ID')); ?></div>
                                            <div class="col-md-12"><?php echo e($job_single->id); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-users-rectangle fs-1 text-danger"></i></div>
                                    <div class="col-md-9 pe-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Career Level')); ?></div>
                                            <div class="col-md-12"><?php echo e($job_single->id); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-briefcase fs-1 text-danger"></i></div>
                                    <div class="col-md-9 px-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Experience')); ?></div>
                                            <div class="col-md-12"><?php echo e($job_single->rJobExperience->name); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5 mb-4">
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-user fs-1 text-danger"></i></div>
                                    <div class="col-md-9 px-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Gender')); ?></div>
                                            <div class="col-md-12"><?php echo e($job_single->rJobGender->name); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-3"><i class="pe-2 fa fa-graduation-cap fs-1 text-danger"></i></div>
                                    <div class="col-md-9 pe-0">
                                        <div class="row">
                                            <div class="col-md-12"><?php echo e(__('Qualifications')); ?></div>
                                            <div class="col-md-12"><?php echo e($job_single->id); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="left-item">                                
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Job Description')); ?></span></div>
                    <p><?php echo $job_single->description; ?></p>
                </div>
                <div class="left-item">
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Job Responsibilities')); ?></span></div>
                    <?php echo nl2br($job_single->responsibility); ?>

                </div>
                <div class="left-item">
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Skills and Abilities')); ?></span></div>
                    <?php echo nl2br($job_single->skill); ?>

                </div>
                <div class="left-item">
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Educational Qualification')); ?></span></div>
                    <?php echo nl2br($job_single->education); ?>

                </div>
                <div class="left-item">
                    <div class="py-3"><span class="fs-5 fw-bolder text-black"><?php echo e(__('Benefits')); ?></span></div>
                    <?php echo nl2br($job_single->benefit); ?>

                </div>
  
                
                <div class="left-item">
                    <div class="py-3 "><span class="fs-4 fw-bolder"><?php echo e(__('Related Jobs')); ?></span></div>
                    
                    <div class="job related-job pt-0 pb-0">
                        <div class="container">
                            <div class="row">

                                <?php $__empty_1 = true; $__currentLoopData = $jobs_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $this_company_id = $item->rCompany->id;
                                        $order_data = \App\Models\Order::where('company_id', $this_company_id)->where('currently_active', 1)->first();
                                        if(date('Y-m-d') > $order_data?->expire_date) {
                                            continue;
                                        }
                                    ?>

                                    <div class="col-md-12 py-2">
                                        <div class="row border">
                                            <div class="col-md-1 pt-4">
                                                <div class="border">
                                                    <a href="<?php echo e(route('job', $item->id)); ?>" data-job-id="174" class="">
                                                        <img class="list-image" src="<?php echo e(asset('uploads/' . $item->rCompany->logo)); ?>" alt="<?php echo e($item->rCompany->company_name); ?>">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-md-9 pt-3">
                                                <div>
                                                    <h5><a class="fw-bold" href="<?php echo e(route('job', $item->id)); ?>"><?php echo e($item->title); ?></a></h5>
                                                    <ul class="list-unstyled fs-7">
                                                        <li>
                                                                <a class ="text-danger" href="javascript:void(0);"><?php echo e($item->rCompany->company_name); ?></a>
                                                                <i class="ms-1 px-1 border-start fa fa-location-dot"></i><?php echo e($item->rJobLocation->name); ?>

                                                                <?php if($item->is_featured == 1): ?><div class="featured badge text-bg-primary"><?php echo e(__('Featured')); ?></div> <?php endif; ?>
                                                                <?php if($item->is_urgent == 1): ?><div class="urgent badge text-bg-danger"><?php echo e(__('Urgent')); ?></div> <?php endif; ?>
                                                        </li>
                                                        <li>
                                                            <i class="px-1 fa fa-calendar-days"></i>Published <?php echo e($item->created_at->diffForHumans()); ?>

                                                            <?php if(date('Y-m-d') > $item->deadline): ?>
                                                                <div class="expired badge text-bg-warning"><?php echo e(__('Expired')); ?></div>
                                                            <?php endif; ?>
                                                            <i class="ms-1 px-1 border-start fa fa-filter"></i><?php echo e($item->rJobCategory->name); ?>

                                                            <i class="ms-1 px-1 border-start fa fa-dollar-sign"></i><?php echo e($item->rJobSalaryRange->name); ?>

                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="col-md-2 pt-5 px-0">
                                                <ul class="list-unstyled fs-7">
                                                    <li>
                                                        <?php if($item->rJobType->id == 1): ?><button type="submit" class="btn btn-fulltime rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 2): ?><button type="submit" class="btn btn-parttime rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 3): ?><button type="submit" class="btn btn-freelance rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 4): ?><button type="submit" class="btn btn-temporary rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        <?php if($item->rJobType->id == 5): ?><button type="submit" class="btn btn-internship rounded-0 btn-job-type"><?php echo e($item->rJobType->name); ?></button><?php endif; ?>
                                                        
                                                        <?php if(!Auth::guard('company')->check()): ?>
                                                            <?php if(Auth::guard('candidate')->check()): ?>
                                                                <?php
                                                                    $count = \App\Models\CandidateBookmark::where('candidate_id', Auth::guard('candidate')->user()->id)->where('job_id', $item->id)->count();
                                                                    if($count > 0) {
                                                                        $bookmark_status = 'bg-danger';
                                                                    } else {
                                                                        $bookmark_status = '';
                                                                    }
                                                                ?>
                                                            <?php else: ?>
                                                                <?php $bookmark_status = ''; ?>
                                                            <?php endif; ?>
                                                            <a class="icon-job-like bg-danger pt-1" href="<?php echo e(route('candidate_bookmark_add', $item->id)); ?>"><i class="fa fa-heart"></i></a>
                                                        <?php endif; ?>
                                                        
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                
                                    <div class="text-danger">No related job found.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 ps-3 pe-0 float-right">
            <div class="container">
                <div class="row border">
                    <div class="col-md-12 p-0">
                        <?php if(date('Y-m-d') > $job_single->deadline): ?>
                            <div class="right-item text-center text-danger py-5">
                                <?php echo e(__('The Application deadline closed.')); ?>

                            </div>
                        <?php else: ?>
                            <div class="right-item mt-4 px-4">
                                <div class="enquery-form">
                                    <form action="<?php echo e(route('job_enquery_email')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="job_title" value="<?php echo e($job_single->title); ?>">
                                        <input type="hidden" name="company_email" value="<?php echo e($job_single->rCompany->email); ?>">
                                        <div class="mb-3">
                                            <input type="text" class="form-control" name="visitor_name" placeholder="Full Name">
                                        </div>
                                        <div class="mb-3">
                                            <input type="text" class="form-control" name="visitor_email" placeholder="Email Address">
                                        </div>
                                        <div class="mb-3">
                                            <input type="text" class="form-control" name="visitor_phone" placeholder="Phone Number">
                                        </div>
                                        <div class="mb-3">
                                            <textarea class="form-control" name="visitor_message" placeholder="Message" rows="5" style="width: 100%;" ></textarea>
                                        </div>
                                        <button type="submit" class="btn bg-warning w-100 py-2 my-3"><i class="pe-1 fa fa-email text-danger"></i><?php echo e(__('CONTACT EMPLOYER')); ?></button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- <?php if($job_single->map_code != null): ?>
                    <div class="row border mt-4">
                    <div class="right-item">
                        <h2><i class="fas fa-file-invoice"></i> Location Map</h2>
                        <div class="location-map">
                            <?php echo nl2br($job_single->map_code); ?>

                        </div>
                    </div>
                    </div>
                <?php endif; ?> -->
                
            </div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/job.blade.php ENDPATH**/ ?>