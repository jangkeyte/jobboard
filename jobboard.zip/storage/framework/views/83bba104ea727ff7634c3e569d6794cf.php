<section id="companies" class="splide" aria-label="Splide Basic HTML Example">
    <div class="splide__track mb-2">
        <ul class="splide__list">
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="splide__slide">
                    <div class="card category-item text-center m-2">
                        <div class="careerfy-seventeen-employers-grid-inner">
                            <figure>
                                <a href="<?php echo e(route('company', $item->id)); ?>">
                                    <?php if(file_exists(asset('uploads/' . $item->logo))): ?>
                                        <img src="<?php echo e(asset('uploads/' . $item->logo)); ?>" alt="<?php echo e($item->company_name); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/images/default_company.jpg')); ?>" alt="<?php echo e($item->company_name); ?>">
                                    <?php endif; ?>
                                </a>
                            </figure>
                            <h2>
                                <a href="<?php echo e(route('company', $item->id)); ?>"><?php echo e($item->company_name); ?></a>
                            </h2>
                            <span><?php echo e($item->rCompanyIndustry->name); ?></span>
                            <small><?php echo e($item->r_job_count); ?> <?php echo e(__('POSITION')); ?></small>
                            <span class="careerfy-jobli-medium3"><i class="fa fa-star"></i></span>
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</section>



<?php $__env->startPush('scripts'); ?>
    <script>
        new Splide('#companies', {
            type: 'loop',
            padding: '1rem',
            perPage: 4,
            breakpoints: {
                768: {
                    perPage: 3,
                },
                640: {
                    perPage: 2,
                },
                480: {
                    perPage: 1,
                },
            }
        }).mount();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/home_companies.blade.php ENDPATH**/ ?>