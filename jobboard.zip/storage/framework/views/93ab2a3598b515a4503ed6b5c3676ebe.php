<div class="careerfy-refejobs-list-inner">
    <?php if(isset($item->is_urgent)): ?>
    <span class="urgntpkg-jobv1"><?php echo e(__('urgent')); ?></span>
    <?php endif; ?>
    <figure>
        <a href="<?php echo e(route('company_candidate_detail', $item->id)); ?>">
            <?php echo $__env->make('front/templates/image', ['image' => $item->photo, 'name' => $item->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </a>
        <figcaption>
            <h2 class="jobsearch-candidate-default-left">
                <a href="<?php echo e(route('company_candidate_detail', $item->id)); ?>"><?php echo e($item->name); ?></a>
                <?php if(isset($item->is_expert)): ?>
                <i class="fa-solid fa-circle-check text-success" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e(__('Expert')); ?>"></i>
                <?php endif; ?>
            </h2>
            <ul class="d-inline">
                <li><?php echo e($item->designation); ?></li>
                <?php if(isset($item->state)): ?>
                <li> | <i class="fa fa-map-marker"></i> <?php echo e($item->state); ?> </li>
                <?php endif; ?>
                <?php if(isset($item->rCandidateSector->name)): ?>
                <li> | <i class="fa-solid fa-layer-group"></i> 
                    <a class=""><?php echo e($item->rCandidateSector->name); ?> </a>
                </li>
                <?php endif; ?>
            </ul>
        </figcaption>
    </figure>
    
    <a href="<?php echo e(route('company_candidate_detail', $item->id)); ?>"
        class="btn btn-light btn-sm text-danger border-danger hover-danger"><span>
            <i class="fa-solid fa-person-circle-plus"></i> <?php echo e(__('Save Candidate')); ?></span></a>
</div>


<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/candidate_listing_candidate_item.blade.php ENDPATH**/ ?>