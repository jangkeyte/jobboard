<div class="container-wrapper container-wrapper-view1">
    <div class="jobsearch-candidate-editor">
        <div class="jobsearch-content-title">
            <h2>About Wanda Montgomery</h2>
        </div>
        <div class="jobsearch-jobdetail-services">
            <ul class="jobsearch-row">
                <li class="academic-level jobsearch-column-4"> <i class="careerfy-icon careerfy-degree-cap"></i>
                    <div class="jobsearch-services-text"><span>Academic Level </span> <small>Certificate</small></div>
                </li>
                <li class="age jobsearch-column-4"> <i class="careerfy-icon careerfy-user-line"></i>
                    <div class="jobsearch-services-text"><span>Age </span> <small>18 - 22 Years</small></div>
                </li>
                <li class="jobsearch-column-4"> <i class="careerfy-icon careerfy-salary"></i>
                    <div class="jobsearch-services-text"><span>Salary </span> <small>1850</small></div>
                </li>
                <li class="Gender jobsearch-column-4"> <i class="careerfy-icon careerfy-user-line-double"></i>
                    <div class="jobsearch-services-text"><span>Gender </span> <small>Female</small></div>
                </li>
                <li class="Industry jobsearch-column-4"> <i class="careerfy-icon careerfy-network"></i>
                    <div class="jobsearch-services-text"><span>Industry </span> <small>Finance</small></div>
                </li>
                <li class="jobsearch-column-4">
                    <i class="jobsearch-icon jobsearch-view"></i>
                    <div class="jobsearch-services-text">Viewed <small>41</small></div>
                </li>
            </ul>
        </div>
        <div class="jobsearch-content-title">
            <h2>About me</h2>
        </div>
        <div class="jobsearch-description">
            <p>Hello my name is Ariana Gande Connor and I’m a Financial Supervisor from Netherlands, Rotterdam. In
                pharetra orci dignissim, blandit mi semper, ultricies diam. Suspendisse malesuada suscipit nunc non
                volutpat. Sed porta nulla id orci laoreet tempor non consequat enim. Sed vitae aliquam velit. Aliquam
                ante accumsan ac est.</p>
            <p>Integer vehicula rhoncus molestie. Morbi ornare ipsum sed sem condimentum, et pulvinar tortor luctus.
                Suspendisse condimentum lorem ut elementum aliquam. Mauris nec erat ut libero vulputate pulvinar.
                Aliquam ante erat, blandit at pretium et, accumsan ac est. Integer vehicula rhoncus molestie. Morbi
                ornare ipsum sed sem condimentum, et pulvinar tortor luctus. Suspendisse condimentum lorem ut elementum
                aliquam. Mauris nec.</p>
        </div>
    </div>
    <div class="jobsearch-candidate-title">
        <h2><i class="jobsearch-icon jobsearch-mortarboard"></i> Education </h2>
    </div>
    <div class="jobsearch-candidate-timeline">
        <ul class="jobsearch-row">
            <li class="jobsearch-column-12">
                <small>2002 - 2004</small>

                <div class="jobsearch-candidate-timeline-text">
                    <span>Walters University</span>
                    <h2><a>Masters in Fine Arts</a></h2>
                    <p>Fussy penguin insect additionally wow absolutely crud meretriciously hastily dalmatian a
                        glowered. outside oh arrogantly vehement.</p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>2012 - 2015</small>

                <div class="jobsearch-candidate-timeline-text">
                    <span>Glibe University</span>
                    <h2><a>Tommers College</a></h2>
                    <p>That one rank beheld bluebird after outside ignobly allegedly more when oh arrogantly vehement
                        irresistibly fussy penguin insect additionally.</p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>2012 - 2015</small>

                <div class="jobsearch-candidate-timeline-text">
                    <span>Miles College</span>
                    <h2><a>Diploma in Fine Arts</a></h2>
                    <p>Outside ignobly allegedly more when oh arrogantly vehement irresistibly fussy penguin insect
                        additionally wow absolutely crud meretriciously a glowered.</p>
                </div>
            </li>
        </ul>
    </div>
    <div class="jobsearch-candidate-title">
        <h2>
            <i class="jobsearch-icon jobsearch-social-media"></i> Experience
        </h2>
    </div>
    <div class="jobsearch-candidate-timeline">
        <ul class="jobsearch-row">
            <li class="jobsearch-column-12">
                <small>
                    2012 - 2013 </small>
                <div class="jobsearch-candidate-timeline-text">
                    <span>Atract Solutions</span>
                    <h2><a>Development Manager</a></h2>
                    <p></p>
                    <p>Arrogantly vehement irresistibly fussy penguin insect additionally wow absolutely crud
                        meretriciously hastily dalmatian a glowered.</p>
                    <p></p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>
                    2014 - 2016 </small>
                <div class="jobsearch-candidate-timeline-text">
                    <span>Barde Workers</span>
                    <h2><a>Senior Php Developer</a></h2>
                    <p></p>
                    <p>Far much that one rank beheld bluebird after outside ignobly allegedly more when oh arrogantly
                        vehement irresistibly fussy penguin insect additionally.</p>
                    <p></p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>
                    2016 - 2017 </small>
                <div class="jobsearch-candidate-timeline-text">
                    <span></span>
                    <h2><a>Self Employed Professional</a></h2>
                    <p></p>
                    <p>Outside ignobly allegedly more when oh arrogantly vehement irresistibly fussy penguin insect
                        additionally wow absolutely crud meretriciously</p>
                    <p></p>
                </div>
            </li>
        </ul>
    </div>
    <div class="jobsearch_progressbar_wrap">
        <div class="jobsearch-row">
            <div class="jobsearch-column-12">
                <div class="jobsearch-candidate-title">
                    <h2><i class="jobsearch-icon jobsearch-design-skills"></i> Expertise </h2>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="85"><span class="title">Sale Product</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 85%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="70"><span class="title">Google Seo</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 70%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="40"><span class="title">Listening</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 40%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="80"><span class="title">Graphic Design</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 80%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="75"><span class="title">Business Sense</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 75%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="95"><span class="title">Creativity</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 95%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="82"><span class="title">Team Group</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 82%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="50"><span class="title">Organizations</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 50%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="85"><span class="title">Flexibilty</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 85%;"></span></div>
                </div>
            </div>
            <div class="jobsearch-column-6">
                <div class="jobsearch_progressbar" data-width="75"><span class="title">Communication</span>
                    <div class="bar-container " style="background-color:#dbdbdb;height:6px;"><span
                            class="backgroundBar"></span><span class="bar"
                            style="background-color: rgb(255, 0, 0); opacity: 1; width: 75%;"></span></div>
                </div>
            </div>
        </div>
    </div>

    <div class="jobsearch-candidate-title">
        <h2><i class="jobsearch-icon jobsearch-briefcase"></i> Portfolio </h2>
    </div>
    <div class="jobsearch-gallery candidate_portfolio">
        <ul class="jobsearch-row grid" style="position: relative; height: 288px;">
            <li class="grid-item jobsearch-column-3" style="position: absolute; left: 0%; top: 0px;">
                <figure>
                    <span class="grid-item-thumb"><small
                            style="background-image: url('https://careerfy.net/perfectjob/wp-content/uploads/our-work4-.jpg');"></small></span>
                    <figcaption>
                        <div class="img-icons">
                            <a href="https://careerfy.net/perfectjob/wp-content/uploads/our-work4-.jpg"
                                class="fancybox-galimg" title="Art Work" data-fancybox-group="group"><i
                                    class="fa fa-image"></i></a>
                            <a href="https://www.themeforest.net" target="_blank"><i class="fa fa-chain"></i></a>
                        </div>
                    </figcaption>
                </figure>
            </li>
            <li class="grid-item jobsearch-column-6" style="position: absolute; left: 24.9315%; top: 0px;">
                <figure>
                    <span class="grid-item-thumb"><small
                            style="background-image: url('https://careerfy.net/perfectjob/wp-content/uploads/our-work3-.jpg');"></small></span>
                    <figcaption>
                        <div class="img-icons">
                            <a href="https://careerfy.net/perfectjob/wp-content/uploads/our-work3-.jpg"
                                class="fancybox-galimg" title="Iphone Aplication" data-fancybox-group="group"><i
                                    class="fa fa-image"></i></a>
                            <a href="https://www.themeforest.net" target="_blank"><i class="fa fa-chain"></i></a>
                        </div>
                    </figcaption>
                </figure>
            </li>
            <li class="grid-item jobsearch-column-3" style="position: absolute; left: 74.9315%; top: 0px;">
                <figure>
                    <span class="grid-item-thumb"><small
                            style="background-image: url('https://careerfy.net/perfectjob/wp-content/uploads/our-work2-.jpg');"></small></span>
                    <figcaption>
                        <div class="img-icons">
                            <a href="https://careerfy.net/perfectjob/wp-content/uploads/our-work2-.jpg"
                                class="fancybox-galimg" title="Lovely Art" data-fancybox-group="group"><i
                                    class="fa fa-image"></i></a>
                            <a href="https://www.themeforest.net" target="_blank"><i class="fa fa-chain"></i></a>
                        </div>
                    </figcaption>
                </figure>
            </li>
            <li class="grid-item jobsearch-column-3" style="position: absolute; left: 0%; top: 144px;">
                <figure>
                    <span class="grid-item-thumb"><small
                            style="background-image: url('https://careerfy.net/perfectjob/wp-content/uploads/our-work1-.jpg');"></small></span>
                    <figcaption>
                        <div class="img-icons">
                            <a href="https://careerfy.net/perfectjob/wp-content/uploads/our-work1-.jpg"
                                class="fancybox-galimg" title="Photo Shoot" data-fancybox-group="group"><i
                                    class="fa fa-image"></i></a>
                            <a href="https://www.themeforest.net" target="_blank"><i class="fa fa-chain"></i></a>
                        </div>
                    </figcaption>
                </figure>
            </li>
            <li class="grid-item jobsearch-column-3" style="position: absolute; left: 74.9315%; top: 144px;">
                <figure>
                    <span class="grid-item-thumb"><small
                            style="background-image: url('https://careerfy.net/perfectjob/wp-content/uploads/our-work5-.jpg');"></small></span>
                    <figcaption>
                        <div class="img-icons">
                            <a href="https://careerfy.net/perfectjob/wp-content/uploads/our-work5-.jpg"
                                class="fancybox-galimg" title="Wood Table Design" data-fancybox-group="group"><i
                                    class="fa fa-image"></i></a>
                            <a href="https://www.themeforest.net" target="_blank"><i class="fa fa-chain"></i></a>
                        </div>
                    </figcaption>
                </figure>
            </li>
        </ul>
    </div>

    <div class="jobsearch-candidate-title">
        <h2><i class="jobsearch-icon jobsearch-trophy"></i> Honors &amp; awards </h2>
    </div>
    <div class="jobsearch-candidate-timeline">
        <ul class="jobsearch-row">
            <li class="jobsearch-column-12">
                <small>2017</small>
                <div class="jobsearch-candidate-timeline-text">
                    <h2><a>Distinguished Service Award</a></h2>
                    <p>Fussy penguin insect additionally wow absolutely crud meretriciously hastily dalmatian a
                        glowered. outside ignobly allegedly more when vehement.</p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>2016</small>
                <div class="jobsearch-candidate-timeline-text">
                    <h2><a>Robin Milner Young Researcher Award</a></h2>
                    <p>That one rank beheld bluebird after outside ignobly allegedly more when oh arrogantly vehement
                        irresistibly fussy penguin insect additionally.</p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>2015</small>
                <div class="jobsearch-candidate-timeline-text">
                    <h2><a>Doctoral Dissertation Award</a></h2>
                    <p>Outside ignobly allegedly more when oh arrogantly vehement irresistibly fussy penguin insect
                        additionally wow absolutely crud meretriciously a glowered.</p>
                </div>
            </li>
            <li class="jobsearch-column-12">
                <small>2014</small>
                <div class="jobsearch-candidate-timeline-text">
                    <h2><a>Programming Languages Achievement</a></h2>
                    <p>Outside ignobly allegedly more when oh arrogantly vehement irresistibly fussy penguin insect
                        additionally wow absolutely hastily dalmatian a glowered.</p>
                </div>
            </li>
        </ul>
    </div>
    <div id="add_review_form_sec" class="jobsearch-candidate-wrap-section jobsearch-margin-bottom">
        <div class="jobsearch-content-title jobsearch-addmore-space">
            <h2>Leave Your Review</h2>
        </div>
        <div class="jobsearch-add-review-con">

            <form autocomplete="off" id="jobsearch-review-form" class="jobsearch-addreview-form" method="post">
                <ul>
                    <li>
                        <div class="review-stars-sec">

                            <div class="review-stars-holder">
                                <label>Education</label>
                                <div class="br-wrapper br-theme-fontawesome-stars"><select
                                        id="review-stars-selector-1" name="user_rating_1" autocomplete="off"
                                        style="display: none;">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                    <div class="br-widget"><a href="#" data-rating-value="1"
                                            data-rating-text="1" class="br-selected br-current"></a><a href="#"
                                            data-rating-value="2" data-rating-text="2"></a><a href="#"
                                            data-rating-value="3" data-rating-text="3"></a><a href="#"
                                            data-rating-value="4" data-rating-text="4"></a><a href="#"
                                            data-rating-value="5" data-rating-text="5"></a></div>
                                </div>
                            </div>

                            <div class="review-stars-holder">
                                <label>Skills</label>
                                <div class="br-wrapper br-theme-fontawesome-stars"><select
                                        id="review-stars-selector-2" name="user_rating_2" autocomplete="off"
                                        style="display: none;">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                    <div class="br-widget"><a href="#" data-rating-value="1"
                                            data-rating-text="1" class="br-selected br-current"></a><a href="#"
                                            data-rating-value="2" data-rating-text="2"></a><a href="#"
                                            data-rating-value="3" data-rating-text="3"></a><a href="#"
                                            data-rating-value="4" data-rating-text="4"></a><a href="#"
                                            data-rating-value="5" data-rating-text="5"></a></div>
                                </div>
                            </div>

                            <div class="review-stars-holder">
                                <label>Communication</label>
                                <div class="br-wrapper br-theme-fontawesome-stars"><select
                                        id="review-stars-selector-3" name="user_rating_3" autocomplete="off"
                                        style="display: none;">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                    <div class="br-widget"><a href="#" data-rating-value="1"
                                            data-rating-text="1" class="br-selected br-current"></a><a href="#"
                                            data-rating-value="2" data-rating-text="2"></a><a href="#"
                                            data-rating-value="3" data-rating-text="3"></a><a href="#"
                                            data-rating-value="4" data-rating-text="4"></a><a href="#"
                                            data-rating-value="5" data-rating-text="5"></a></div>
                                </div>
                            </div>
                        </div>
                        <div class="review-overall-stars-sec">
                            <span class="rating-text">Overall Rating</span>
                            <span class="rating-num">0</span>
                            <div class="jobsearch-company-rating"><span class="jobsearch-company-rating-box"
                                    style="width: 20%;"></span></div>
                        </div>
                    </li>
                    <li>
                        <input type="text" name="user_name" placeholder="Your Name">
                    </li>
                    <li>
                        <input type="text" name="user_email" placeholder="Email Address">
                    </li>
                    <li>
                        <textarea name="user_comment" placeholder="Your Review"></textarea>
                    </li>
                    <li>
                        <input type="hidden" name="review_post" value="184">
                        <input type="hidden" name="action" value="jobsearch_user_review_post">
                        <input type="submit" id="jobsearch-review-submit-btn" value="Submit now">
                        <span class="jobsearch-review-loader"></span>
                        <span class="jobsearch-review-msg"></span>
                    </li>
                </ul>
            </form>
        </div>
    </div>
</div>
<?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/candidate_profile_detail.blade.php ENDPATH**/ ?>