

<?php $__env->startSection('heading', 'Create Package'); ?>

<?php $__env->startSection('button'); ?>
<div>
    <a href="<?php echo e(route('admin_package')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> View All</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin_package_store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Package Name *</label>
                                    <input type="text" class="form-control" name="package_name" value="<?php echo e(old('package_name')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Package Price *</label>
                                    <input type="text" class="form-control" name="package_price" value="<?php echo e(old('package_name')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Number of Days *</label>
                                    <input type="text" class="form-control" name="package_days" value="<?php echo e(old('package_days')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Display Time *</label>
                                    <input type="text" class="form-control" name="package_display_time" value="<?php echo e(old('package_display_time')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Total Allowed Jobs *</label>
                                    <input type="text" class="form-control" name="total_allowed_jobs" value="<?php echo e(old('total_allowed_jobs')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Total Allowed Featured Jobs *</label>
                                    <input type="text" class="form-control" name="total_allowed_featured_jobs" value="<?php echo e(old('total_allowed_featured_jobs')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Total Allowed Photos *</label>
                                    <input type="text" class="form-control" name="total_allowed_photos" value="<?php echo e(old('total_allowed_photos')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="">Total Allowed Videos *</label>
                                    <input type="text" class="form-control" name="total_allowed_videos" value="<?php echo e(old('total_allowed_videos')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/package_create.blade.php ENDPATH**/ ?>