

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/banner.jpg')); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Compani
                    /es Listing</h2>
            </div>
        </div>
    </div>
</div>
<div class="company-result">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="company-filter">
                    <form action="<?php echo e(url('company-listing')); ?>" method="get">
                        <div class="widget">
                            <h2>Company Title</h2>
                            <input type="text" class="form-control" name="name" value="<?php echo e($form_name); ?>" placeholder="Company Name...">
                        </div>
                        <div class="widget">
                            <h2>Company Industry</h2>
                            <select name="industry" class="form-control select2">
                                <option value="">Company Industry</option>
                                <?php $__currentLoopData = $company_industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_industry == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Company Location</h2>
                            <select name="location" class="form-control select2">
                                <option value="">Company Location</option>
                                <?php $__currentLoopData = $company_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_location == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Company Size</h2>
                            <select name="size" class="form-control select2">
                                <option value="">Company Size</option>
                                <?php $__currentLoopData = $company_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($form_size == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="widget">
                            <h2>Founded On</h2>
                            <select name="founded_on" class="form-control select2">
                                <option value="">Founded On</option>
                                <?php for($i = 1990; $i <= date('Y'); $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php if($form_founded_on == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="filter-button">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="fas fa-search"></i> <?php echo e($home_page_data->search ?? 'Filter'); ?>

                            </button>
                        </div>
                    </form>

                    <div class="advertisement">
                        <a href=""><img src="<?php echo e(asset('uploads/ad-2.png')); ?>" alt=""></a>
                    </div>

                </div>
            </div>

            <div class="col-md-9">
                <div class="company">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="search-result-header">
                                    <i class="fas fa-search"></i> Search Result for Company Listing
                                </div>
                            </div>
                            <?php if(!$companies->count()): ?>
                                <div class="text-danger">No result found</div>
                            <?php else: ?>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <div class="item d-flex justify-content-start">
                                            <div class="logo">
                                                <img src="<?php echo e(asset('uploads/' . ($item->rCompany->logo ?? 'default.png') )); ?>" alt="<?php echo e($item->company_name); ?>">
                                            </div>
                                            <div class="text">
                                                <h3>
                                                    <a href="<?php echo e(route('company', $item->id)); ?>"><?php echo e($item->company_name); ?></a>
                                                </h3>
                                                <div class="detail-1 d-flex justify-content-start">
                                                    <div class="category"><?php echo e($item->rCompanyIndustry->name ?? 'Industry'); ?></div>
                                                    <div class="location"><?php echo e($item->rCompanyLocation->name ?? 'Location'); ?></div>
                                                </div>
                                                <div class="detail-2 d-flex-justify-content-start">
                                                   <?php echo substr($item->description, 0, 220) . '...'; ?>

                                                </div>
                                                <div class="open-position">
                                                    <span class="badge bg-primary"><?php echo e($item->r_job_count); ?> Open Positions</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <?php echo e($companies->links()); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/company_listing.blade.php ENDPATH**/ ?>