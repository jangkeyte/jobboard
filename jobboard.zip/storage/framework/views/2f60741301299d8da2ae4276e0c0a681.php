<section id="job-category" class="splide" aria-label="Splide Basic HTML Example">
    <div class="splide__track mb-2">
        <ul class="splide__list">
            <?php $__currentLoopData = $job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="splide__slide">
                    <div class="card category-item text-center m-4">
                        <a href="<?php echo e(url('job-listing?category=' . $item->id)); ?>">
                            <div class="card-body">
                                <div class="icon fs-1 text-danger mb-3">
                                    <i class="<?php echo e($item->icon); ?>"></i>
                                </div>
                                <h2 ><?php echo e($item->name); ?></h2>
                                <span class="btn btn-danger btn-sm px-3"><?php echo e($item->r_job_count); ?></span>
                            </div>
                        </a>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
    new Splide( '#job-category', {
        type: 'loop',
        padding: '1rem',
        perPage: 4,
        breakpoints: {
            768: {
                perPage: 3,
            },
            640: {
                perPage: 2,
            },
            480: {
                perPage: 1,
            },
        }
    } ).mount();
</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/templates/home_job_categories.blade.php ENDPATH**/ ?>