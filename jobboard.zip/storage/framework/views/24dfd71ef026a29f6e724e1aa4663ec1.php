

<?php $__env->startSection('main_content'); ?>

<?php if(isset($candidate_single)): ?>

<div class="page-top-detail" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_job_detail ?? 'banner_default.jpg'))); ?>)"></div>
<div class="container w-75 bg-white" style="margin-top: -150px;">
    <div class="row mt-4">
        
        <div class="col-md-4 ps-3 pe-0 float-right">
            <div class="container">
                <?php echo $__env->make('front/templates/candidate_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
            </div>
        </div>

        <div class="col-md-8 pe-3 ps-0 float-left">
            <?php echo $__env->make('front/templates/candidate_profile_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>

    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/candidate_detail.blade.php ENDPATH**/ ?>