

<?php $__env->startSection('seo_title'); ?><?php echo e($faq_page_item->title ?? __('SEO Title')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php echo e($faq_page_item->meta_description ?? __('SEO Meta Description')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . ($global_banner_data->banner_faq ?? 'banner_default.jpg'))); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($faq_page_item->heading ?? __('SEO Heading')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content faq">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center">
                <div class="accordion w-100" id="accordionExample">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion" id="heading<?php echo e($item->id); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($item->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($item->id); ?>">
                                <?php echo $item->question; ?>

                            </button>
                        </h2>
                        <div id="collapse<?php echo e($item->id); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo e($item->id); ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <?php echo nl2br($item->answer); ?>

                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/front/faq.blade.php ENDPATH**/ ?>