

<?php $__env->startSection('heading', 'Companies'); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header ui-sortable-handle" style="cursor: move;">
                    <h3 class="card-title">
                    <i class="ion ion-clipboard mr-1"></i>
                    To Do List
                    </h3>
                    <div class="card-tools">
                        <?php echo e($companies->links()); ?>

                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Company Name</th>
                                    <th>Person Name</th>
                                    <th>Username</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->company_name); ?></td>
                                    <td><?php echo e($item->person_name); ?></td>
                                    <td><?php echo e($item->username); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin_companies_detail', $item->id)); ?>" class="btn btn-primary btn-sm"><i class="bi bi-eye-fill"></i> <?php echo e(__('Detail')); ?></a>
                                        <?php if($item->rJob->count() > 0): ?>
                                        <a href="<?php echo e(route('admin_companies_jobs', $item->id)); ?>" class="btn btn-success btn-sm"><i class="bi bi-clipboard-data-fill"></i> <?php echo e(__('Jobs')); ?> (<?php echo e($item->rJob->count()); ?>)</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('admin_companies_delete', $item->id)); ?>" class="btn btn-danger btn-sm" onClick="return confirm('Are you sure?');"><i class="bi bi-trash-fill"></i> <?php echo e(__('Delete')); ?></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/companies.blade.php ENDPATH**/ ?>