

<?php $__env->startSection('seo_title'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('seo_meta_description'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<div class="page-top" style="background-image: url(<?php echo e(asset('uploads/' . $global_banner_data->banner_company_panel)); ?>)">
    <div class="bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($faq_page_item->heading ?? __('Edit Profile')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="page-content user-panel">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="card">
                    <?php echo $__env->make('company.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-9 col-md-12">        
                <form action="<?php echo e(route('company_edit_profile_update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>      
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for=""><?php echo e(__('Existing Logo')); ?></label>
                            <div class="form-group">
                                <?php if(Auth::guard('company')->user()->logo == ''): ?>
                                    <img src="<?php echo e(asset('uploads/default_company_logo.jpg')); ?>" alt="" class="logo w-10">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('uploads/' . Auth::guard('company')->user()->logo)); ?>" alt="" class="logo">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for=""><?php echo e(__('Change Logo')); ?></label>
                            <div class="form-group"><input type="file" name="logo"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Company Name')); ?> *</label>
                            <div class="form-group"><input type="text" name="company_name" class="form-control" value="<?php echo e(Auth::guard('company')->user()->company_name); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Contact Person')); ?> *</label>
                            <div class="form-group"><input type="text" name="person_name" class="form-control" value="<?php echo e(Auth::guard('company')->user()->person_name); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Username')); ?> *</label>
                            <div class="form-group"><input type="text" name="username" class="form-control" value="<?php echo e(Auth::guard('company')->user()->username); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Email')); ?> *</label>
                            <div class="form-group"><input type="text" name="email" class="form-control" value="<?php echo e(Auth::guard('company')->user()->email); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Phone')); ?> *</label>
                            <div class="form-group"><input type="text" name="phone" class="form-control" value="<?php echo e(Auth::guard('company')->user()->phone); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Address')); ?> *</label>
                            <div class="form-group"><input type="text" name="address" class="form-control" value="<?php echo e(Auth::guard('company')->user()->address); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Company Location')); ?> *</label>
                            <div class="form-group">
                                <select name="company_location_id" class="form-control">
                                    <?php $__currentLoopData = $company_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == Auth::guard('company')->user()->company_location_id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Company Industry')); ?> *</label>
                            <div class="form-group">
                                <select name="company_industry_id" class="form-control">
                                    <?php $__currentLoopData = $company_industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == Auth::guard('company')->user()->company_industry_id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Company Size')); ?> *</label>
                            <div class="form-group">
                                <select name="company_size_id" class="form-control">
                                    <?php $__currentLoopData = $company_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == Auth::guard('company')->user()->company_size_id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Founded On')); ?> *</label>
                            <div class="form-group">
                                <select name="founded_on" class="form-control select2">
                                    <?php for($i=date('Y'); $i>=1900; $i--): ?>
                                        <option value="<?php echo e($i); ?>" <?php if($i == Auth::guard('company')->user()->founded_on): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Website')); ?></label>
                            <div class="form-group"><input type="text" name="website" class="form-control" value="<?php echo e(Auth::guard('company')->user()->website); ?>"></div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for=""><?php echo e(__('About Company')); ?> *</label>
                            <div class="form-group">
                                <textarea name="description" class="form-control editor w-100" cols="30" rows="10"><?php echo e(Auth::guard('company')->user()->description); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Monday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_mon" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_mon); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Tuesday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_tue" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_tue); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Wednesday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_web" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_web); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Thursday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_thu" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_thu); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Friday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_fri" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_fri); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Saturday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_sat" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_sat); ?>"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Opening Hour') . ' (' . __('Sunday') . ')'); ?></label>
                            <div class="form-group"><input type="text" name="oh_sun" class="form-control" value="<?php echo e(Auth::guard('company')->user()->oh_sun); ?>"></div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for=""><?php echo e(__('Location Map') . ' (' . __('Google Map Code') . ')'); ?></label>
                            <div class="form-group"><textarea name="map_code" class="w-100" cols="30" rows="10"><?php echo e(Auth::guard('company')->user()->map_code); ?></textarea></div>
                        </div>                        
                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Facebook')); ?></label>
                            <div class="form-group"><input type="text" name="facebook" class="form-control" value="<?php echo e(Auth::guard('company')->user()->facebook); ?>"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Twitter')); ?></label>
                            <div class="form-group"><input type="text" name="twitter" class="form-control" value="<?php echo e(Auth::guard('company')->user()->twitter); ?>"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Linkedin')); ?></label>
                            <div class="form-group"><input type="text" name="linkedin" class="form-control" value="<?php echo e(Auth::guard('company')->user()->linkedin); ?>"></div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for=""><?php echo e(__('Instagram')); ?></label>
                            <div class="form-group"><input type="text" name="instagram" class="form-control" value="<?php echo e(Auth::guard('company')->user()->instagram); ?>"></div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group"><input type="submit" value="<?php echo e(__('Update')); ?>" class="btn btn-primary"></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/company/edit_profile.blade.php ENDPATH**/ ?>