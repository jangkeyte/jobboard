<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.6.0/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>"><?php /**PATH D:\Clouds\OneDrive - MSFT\Data\Projects\Laravel\jobboard\resources\views/admin/layout/styles.blade.php ENDPATH**/ ?>