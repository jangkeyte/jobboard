<!--begin::Footer-->
<footer class="app-footer"> 
    <!--begin::To the end-->
    <div class="float-end d-none d-sm-inline"><b>Version</b> 1.1.0</div> <!--end::To the end--> 
    <!--begin::Copyright--> 
    <strong>Copyright &copy; 2024 <a href="https://jangkeyte.com">Jang Keyte</a>.</strong> All rights reserved.
    <!--end::Copyright-->
</footer> <!--end::Footer-->

@include('admin.layout.scripts')