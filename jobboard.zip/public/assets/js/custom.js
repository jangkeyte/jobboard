(function($){
    "use strict";
    /*
    $(document).ready(function() {
        $('#example1').DataTable();
    })

    $('.icp_demo').iconpicker();

    $('.datepicker').datepicker({ format: "yyyy/mm/dd" });
    $('.timepicker').timepicker({
        icons:
        {
            up: 'fa fa-angle-up',
            down: 'fa fa-angle-down'
        }
    });
    */
    tinymce.init({
        selector: ".editor",
        height: "300",
    });

})(jQuery);