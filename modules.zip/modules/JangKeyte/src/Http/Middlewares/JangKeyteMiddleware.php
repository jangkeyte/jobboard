<?php

namespace Modules\JangKeyte\src\Http\Middleware;

class JangKeyteMiddleware extends Middleware
{
    
}
