<div class="card">
    <div class="card-header">
        @yield('header-title')
    </div>
    <div class="card-body">
        @yield('main-content')
    </div>
</div>