<h1>Hello World</h1>
<p>
    This view is loaded from module
</p>