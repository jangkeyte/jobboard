<div data-v-054c4df7="" class="sidebar-filter">
	<header>
		<h1><span>Filter</span> <div class="right"><label>
                    Remove All
                </label> <i class="icon close-icon"></i></div></h1></header>
	<div class="form-group ">
		<label>ID</label>
		<div class="field-container"><span class="control"><i class="icon add-icon"></i> ID
                        </span>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<label>Sales Person</label>
		<div class="field-container">
			<select class="control">
				<option disabled="disabled" value=""> Chọn người dùng </option>
				<option value="1"> Quản trị viên tối cao </option>
			</select>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<label>Subject</label>
		<div class="field-container"><span class="control"><i class="icon add-icon"></i> Subject
                        </span>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<label>Tags</label>
		<div class="field-container"><span class="control"><i class="icon add-icon"></i> Tags
                        </span>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<label>Nguồn Khách hàng tiềm năng</label>
		<div class="field-container">
			<select class="control">
				<option disabled="disabled" value=""> Chọn người dùng </option>
				<option value="1"> Email </option>
				<option value="2"> Website </option>
				<option value="3"> Form liên hệ trên Website </option>
				<option value="4"> Điện thoại </option>
				<option value="5"> Trực tiếp </option>
			</select>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<label>Lead Value</label>
		<div class="field-container"><span class="control"><i class="icon add-icon"></i> Lead Value
                        </span>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<label>Contact Person</label>
		<div class="field-container"><span class="control"><i class="icon add-icon"></i> Contact Person
                        </span>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group ">
		<!---->
		<div class="field-container">
			<!---->
			<!---->
		</div>
	</div>
	<div class="form-group ">
		<label>Rotten Lead</label>
		<div class="field-container">
			<select class="control">
				<option disabled="disabled" value=""> Lựa chọn các phương án </option>
				<option value="0"> Không </option>
				<option value="1"> Vâng </option>
			</select>
			<div class="selected-options"></div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group date">
		<label>Expected Close Date</label>
		<div class="field-container">
			<div id="dateRange9" class="form-group date">
				<div class="date-container">
					<input type="text" placeholder="Start Date" class="control half flatpickr-input">
				</div> <span class="middle-text">to</span>
				<div class="date-container">
					<input type="text" placeholder="End Date" class="control half flatpickr-input">
				</div>
			</div> <i class="icon close-icon"></i></div>
	</div>
	<div class="form-group date">
		<label>Created Date</label>
		<div class="field-container">
			<div id="dateRange10" class="form-group date">
				<div class="date-container">
					<input type="text" placeholder="Start Date" class="control half flatpickr-input">
				</div> <span class="middle-text">to</span>
				<div class="date-container">
					<input type="text" placeholder="End Date" class="control half flatpickr-input">
				</div>
			</div> <i class="icon close-icon"></i></div>
	</div>
</div>