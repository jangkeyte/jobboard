<div class="brand-logo">
	<a href="/">
		<img src="{{ asset('/assets/images/logo.png') }}" alt="JangKeyte CRM">
	</a>
</div>