<div data-v-054c4df7="" class="table-header">
	<h1 data-v-054c4df7=""><nav data-v-054c4df7="" aria-label="breadcrumb"><ol data-v-054c4df7="" class="breadcrumb"><li data-v-054c4df7="" class="breadcrumb-item"><a data-v-054c4df7="" href="https://crm.website.name.vn/admin/dashboard">Điều khiển</a></li> <li data-v-054c4df7="" aria-current="page" class="breadcrumb-item active">Khách hàng</li></ol></nav>
                Khách hàng tiềm năng                
            </h1>
	<div data-v-054c4df7="" class="table-action"><span data-v-054c4df7="" class="export-import"><i data-v-054c4df7="" class="icon export-icon"></i> <span data-v-054c4df7="">Export</span></span> <a data-v-054c4df7="" href="https://crm.website.name.vn/admin/leads/create" class="btn btn-md btn-primary">Tạo mới Khách hàng tiềm năng</a></div>
</div>