<footer id="footer" class="footer-wrapper bg-dark-gradient footer">
    <div class="footer-top">
        <div class="container">
            
        </div>
    </div>
    <div class="footer-bottom footer-border-top light py-3">
        <div class="container text-center">
            <p class="m-0 text-white">© 2023 copyright <a href="http://ttpc.ktxhcm.edu.vn" class="text-reset">ĐHQG TPHCM</a></p>
        </div>
    </div>
</footer><!-- .footer-wrapper -->
