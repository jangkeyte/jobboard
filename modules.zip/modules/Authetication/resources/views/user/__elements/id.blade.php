{!! Form::text('id', isset($default) ? $default : '', array('hidden')); !!}
