@extends('Authetication::master')

@section('title', 'Đăng nhập thành công')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3 mgt80">
            <div class="login-panel card card-default">
                <div class="card-header">
                    <h3 class="card-title">Đăng nhập</h3>
                </div>
                <div class="card-body">
                    Đăng nhập thành công!!!
                </div>
            </div>
        </div>
    </div>
</div>

@stop
