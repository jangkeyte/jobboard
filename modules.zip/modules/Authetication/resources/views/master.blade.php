@extends('JangKeyte::master')

@section('content')

    @yield('entry_content')

@endsection