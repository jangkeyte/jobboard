<a href="{!! route('user.create') !!}" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#newUserModal" data-bs-whatever="user"><i class="fa fa-edit"></i> Thêm mới</a>
