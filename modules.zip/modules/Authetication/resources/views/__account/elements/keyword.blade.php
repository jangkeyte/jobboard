<div class="form-group">
    <input class="form-control input-sm" id="keyword" name="keyword" placeholder="Từ khóa" type="text" value="">
</div>