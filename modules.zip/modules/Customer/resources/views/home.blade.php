@extends('master')

@section('title','đây là trang chủ')

@section('content')

<p> Đây là phần content</p>

@endsection