<div class="container-md container-fluid mt-3">
    <div class="mt-4 p-3 bg-danger text-white rounded">
        <h1 class="fs-1 fw-bold pb-2">Cảnh báo!!! Không được phép truy cập</h1>             
        <div class="alert alert-danger" role="alert">
            Bạn không đủ quyền hạn để truy cập khu vực này, xin vui lòng quay lại <a href="{!! route('dashboard') !!}" class="alert-link">Trang chủ</a>.
        </div>
    </div>
</div>